/* 하우지 운영자 사이트 동작 */
(() => {
  'use strict';
  const A = window.HOWGEE_ADMIN || {};
  const $ = (id) => document.getElementById(id);
  const TYPES = ['원룸', '투룸', '쓰리룸', '오피스텔', '아파트', '빌라', '상가'];
  const DEALS = ['월세', '전세', '매매', '단기'];
  const STATUSES = ['거래가능', '계약진행중', '거래완료', '비공개'];
  const INQ = ['신규', '연락함', '완료'];
  const NUM = ['price', 'rent', 'maint', 'area', 'supply_area', 'rooms', 'baths', 'total_floors'];
  const NUM_LABEL = { price: '보증금/매매가', rent: '월세', maint: '관리비', area: '전용면적', supply_area: '공급면적', rooms: '방 수', baths: '욕실 수', total_floors: '총층수' };
  const DECIMALS = { price: 1, rent: 1, maint: 1, area: 2, supply_area: 2 }; // 나머지는 정수. 가격 소수 1자리 = 천원
  const TEXT = ['title', 'sido', 'gu', 'dong', 'ptype', 'deal', 'status', 'floor', 'move_in', 'parking', 'approval_date', 'direction', 'pet', 'tags', 'description', 'unit', 'owner_contact', 'memo'];

  const S = { items: [], inq: [], view: 'list', filterStatus: '', inqTab: '신규', editWho: null, edit: null, pending: [], dirty: false, busy: false };

  // ---------- 도우미 ----------
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  // 가격은 만원 단위 숫자 (소수 1자리 = 천원). 손님 사이트(public/js/app.js)와 같은 규칙
  function won(n) {
    n = Number(n);
    if (!Number.isFinite(n) || n <= 0) return '0';
    const t = Math.round(n * 10); // 천원 단위
    const eok = Math.floor(t / 100000), man = Math.floor((t % 100000) / 10), chun = t % 10;
    return [eok && `${eok}억`, man && `${man.toLocaleString()}만`, chun && `${chun}천`].filter(Boolean).join(' ');
  }
  const isMonthly = (deal) => deal === '월세' || deal === '단기';
  // 거래 1개의 가격 글자: 손님 사이트와 같은 규칙
  const priceText = (l) => isMonthly(l.deal)
    ? `${l.deal} ${l.price > 0 ? won(l.price).replace(/만$/, '') : '무보증'} / ${won(l.rent || 0)}`
    : `${l.deal} ${won(l.price)}`;
  // 추가 거래 목록 (서버에는 JSON 글자로 저장됨)
  const extrasOf = (l) => { try { const a = JSON.parse(l.extra_deals || '[]'); return Array.isArray(a) ? a : []; } catch { return []; } };
  const extraText = (l) => extrasOf(l).map(priceText).join(' · ');
  // 입력칸 글자 → 숫자 (쉼표·공백 무시). 빈칸 = null, 잘못된 값 = NaN
  const parseNum = (v) => { const t = String(v ?? '').replace(/[,\s]/g, ''); return t === '' ? null : (/^\d+(\.\d+)?$/.test(t) ? Number(t) : NaN); };
  const kst = (iso) => {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleString('ko-KR', { timeZone: 'Asia/Seoul', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false });
  };
  const custBase = () => (A.CUSTOMER_SITE_URL || '').replace(/\/+$/, '');
  function toast(msg, err = false) {
    const t = $('toast');
    t.textContent = msg;
    t.className = `toast show${err ? ' err' : ''}`;
    clearTimeout(toast.t);
    toast.t = setTimeout(() => (t.className = 'toast'), err ? 4500 : 2200);
  }
  async function api(path, { method = 'GET', body, form } = {}) {
    const opt = { method, headers: {}, credentials: 'same-origin' };
    if (method !== 'GET') opt.headers['X-Howgee'] = '1';
    if (form) opt.body = form;
    else if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
    let r;
    try { r = await fetch(path, opt); } catch {
      throw new Error('서버에 연결하지 못했어요. 로그인이 만료됐을 수 있으니 새로고침해 주세요.');
    }
    const d = await r.json().catch(() => ({}));
    if (r.status === 401) showGate('로그인이 만료됐어요. 다시 로그인해 주세요.');
    if (!r.ok || !d.ok) { const err = new Error(d.error || `오류가 발생했어요 (${r.status})`); err.status = r.status; throw err; }
    return d;
  }
  // 로그인 화면 보이기 (구글 계정 로그인 버튼)
  function showGate(msg) {
    $('gateMsg').textContent = msg || '';
    $('gate').hidden = false;
  }
  function download(name, text, type) {
    const blob = new Blob([text], { type });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  function copy(text, msg) { navigator.clipboard.writeText(text).then(() => toast(msg || '복사했어요'), () => toast('복사하지 못했어요', true)); }
  const today = () => new Date(Date.now() + 9 * 3600e3).toISOString().slice(0, 10);

  // ---------- 화면 전환 ----------
  function show(view) {
    if (S.view === 'edit' && view !== 'edit' && S.dirty && !confirm('저장하지 않은 내용이 있어요. 나갈까요?')) return false;
    if (view === 'new') { openEditor(null); view = 'edit'; }
    S.view = view;
    for (const v of ['list', 'edit', 'inq', 'backup']) $(`v-${v}`).hidden = v !== view;
    document.querySelectorAll('.side .nav[data-view]').forEach((b) => b.classList.toggle('on', b.dataset.view === view || (view === 'edit' && b.dataset.view === 'new' && !S.edit)));
    if (view === 'list') loadList();
    if (view === 'inq') loadInq();
    window.scrollTo(0, 0);
    return true;
  }

  // ---------- 매물 목록 ----------
  async function loadList() {
    try {
      const d = await api('/api/admin/listings');
      S.items = d.items;
      renderList();
      fillDatalists();
    } catch (e) { toast(e.message, true); }
  }
  function renderList() {
    const counts = Object.fromEntries(STATUSES.map((s) => [s, S.items.filter((l) => l.status === s).length]));
    $('stats').innerHTML = [['', '전체', S.items.length], ...STATUSES.map((s) => [s, s, counts[s]])]
      .map(([k, label, n]) => `<button class="stat ${S.filterStatus === k ? 'on' : ''}" data-fs="${k}"><b>${n}</b><span>${label}</span></button>`).join('');
    const q = $('q').value.trim().toLowerCase();
    const deal = $('qDeal').value;
    const list = S.items.filter((l) => (!S.filterStatus || l.status === S.filterStatus) && (!deal || l.deal === deal || extrasOf(l).some((d) => d.deal === deal))
      && (!q || [l.id, l.title, l.sido, l.gu, l.dong, l.unit, l.memo, l.tags].join(' ').toLowerCase().includes(q)));
    $('rows').innerHTML = list.length ? list.map((l) => `
      <tr data-id="${esc(l.id)}">
        <td>${l.photos.length ? `<img class="th-img" src="/api/admin/photo/${esc(l.photos[0])}?s=t" loading="lazy" alt="">` : '<div class="noimg">사진 없음</div>'}</td>
        <td><div class="t-title">${esc(l.title)}</div><div class="t-sub">${[esc([l.sido, l.gu, l.dong].filter(Boolean).join(' ')), l.unit ? `🔒${esc(l.unit)}` : '', esc(l.id)].filter(Boolean).join(' · ')}</div></td>
        <td class="price">${esc(priceText(l))}${extrasOf(l).length ? `<div class="t-sub">+ ${esc(extraText(l))}</div>` : ''}${l.maint ? `<div class="t-sub">관리비 ${esc(won(l.maint))}원</div>` : ''}</td>
        <td>${esc(l.ptype)}<div class="t-sub">${l.area ? `${l.area}㎡` : ''}${l.rooms != null ? ` · 방${l.rooms}` : ''}</div></td>
        <td><select class="status" data-st="${esc(l.id)}" data-v="${esc(l.status)}">${STATUSES.map((s) => `<option ${s === l.status ? 'selected' : ''}>${s}</option>`).join('')}</select></td>
        <td><b>${Number(l.views || 0).toLocaleString()}</b></td>
        <td class="t-sub">${kst(l.updated_at)}</td>
        <td><div class="acts"><button class="btn sm" data-edit="${esc(l.id)}">수정</button><button class="btn sm" data-link="${esc(l.id)}">링크</button><button class="btn sm danger" data-del="${esc(l.id)}">삭제</button></div></td>
      </tr>`).join('') : `<tr><td colspan="8" class="empty">${S.items.length ? '조건에 맞는 매물이 없어요.' : '아직 등록한 매물이 없어요. 오른쪽 위 "새 매물 등록"을 눌러 시작하세요.'}</td></tr>`;
  }
  function fillDatalists() {
    const uniq = (k) => [...new Set(S.items.map((l) => l[k]).filter(Boolean))];
    $('dlSido').innerHTML = uniq('sido').map((v) => `<option value="${esc(v)}">`).join('');
    $('dlGu').innerHTML = uniq('gu').map((v) => `<option value="${esc(v)}">`).join('');
  }
  async function setStatus(id, status, sel) {
    try {
      await api(`/api/admin/listings/${id}`, { method: 'PUT', body: { status } });
      const l = S.items.find((x) => x.id === id);
      if (l) { l.status = status; l.updated_at = new Date().toISOString(); }
      if (sel) sel.dataset.v = status;
      renderList();
      toast(status === '거래완료' || status === '비공개' ? `"${status}"로 바꿨어요 — 손님 사이트에서 숨겨집니다` : `"${status}"로 바꿨어요`);
    } catch (e) { toast(e.message, true); loadList(); }
  }
  async function delListing(id) {
    const l = S.items.find((x) => x.id === id) || S.edit;
    if (!confirm(`"${l ? l.title : id}" 매물을 삭제할까요?\n\n· 매물 정보는 바로 지워지고 되돌릴 수 없어요.\n· 사진은 구글 드라이브 휴지통으로 이동해요 (30일 안에 드라이브에서 복구 가능).\n\n거래가 끝난 매물은 삭제 대신 "거래완료"로 바꾸는 것도 방법이에요.`)) return;
    try {
      const r = await api(`/api/admin/listings/${id}`, { method: 'DELETE' });
      toast(r.driveWarning ? `삭제했어요. 단, ${r.driveWarning}` : '삭제했어요', !!r.driveWarning);
      S.dirty = false;
      show('list');
    } catch (e) { toast(e.message, true); }
  }

  // ---------- 작성·수정 ----------
  const form = $('ed');
  form.ptype.innerHTML = TYPES.map((t) => `<option>${t}</option>`).join('');
  form.deal.innerHTML = DEALS.map((t) => `<option>${t}</option>`).join('');
  form.status.innerHTML = STATUSES.map((t) => `<option>${t}</option>`).join('');

  function openEditor(l) {
    S.edit = l ? { ...l, photos: [...(l.photos || [])] } : null;
    clearPending();
    form.reset();
    for (const k of [...NUM, ...TEXT]) if (form[k]) form[k].value = l && l[k] != null ? l[k] : '';
    if (!l) { form.status.value = '거래가능'; form.deal.value = '월세'; form.ptype.value = '원룸'; }
    renderExtras(l ? extrasOf(l) : []);
    $('editTitle').textContent = l ? `매물 수정 · ${l.id}` : '새 매물 등록';
    $('saveBtn').textContent = l ? '수정 저장하기' : '등록하기';
    $('metaBox').hidden = !l;
    if (l) {
      $('metaInfo').innerHTML = `매물번호 ${esc(l.id)} · 조회 ${Number(l.views || 0).toLocaleString()}<br>등록 ${kst(l.created_at)} · 수정 ${kst(l.updated_at)}`;
      const url = custBase() ? `${custBase()}/?id=${encodeURIComponent(l.id)}` : '';
      $('viewCust').href = url || '#';
      $('viewCust').style.display = url ? '' : 'none';
    }
    onDeal();
    renderPhotos();
    S.dirty = false;
  }
  // ---------- 추가 거래 ----------
  // 기본 거래 외의 유형마다 한 줄: [✓ 전세도 가능] 전세금 / [✓ 월세도 가능] 보증금·월세
  function renderExtras(list) {
    const have = Object.fromEntries(list.map((d) => [d.deal, d]));
    const amt = (deal, key, label, v) => `<label class="f">${label}<span class="unit" data-unit="만원"><input data-xd="${deal}" data-xk="${key}" data-dec="1" type="text" inputmode="decimal" maxlength="12" value="${v != null ? esc(v) : ''}"></span></label>`;
    $('extraDeals').innerHTML = DEALS.map((deal) => {
      const d = have[deal];
      const fields = isMonthly(deal)
        ? amt(deal, 'price', '보증금 (없으면 0)', d && d.price) + amt(deal, 'rent', deal === '단기' ? '월 임대료' : '월세', d && d.rent)
        : amt(deal, 'price', deal === '전세' ? '전세금' : '매매가', d && d.price);
      return `<div class="xd" data-row="${deal}"><label class="chk"><input type="checkbox" data-xon="${deal}" ${d ? 'checked' : ''}> ${deal}도 가능</label>
        <div class="fg" ${d ? '' : 'hidden'}>${fields}</div></div>`;
    }).join('');
    syncExtras();
  }
  // 기본 거래와 같은 줄은 숨기고 체크 해제
  function syncExtras() {
    for (const row of document.querySelectorAll('#extraDeals .xd')) {
      const same = row.dataset.row === form.deal.value;
      row.hidden = same;
      const on = row.querySelector('[data-xon]');
      if (same) on.checked = false;
      row.querySelector('.fg').hidden = !on.checked;
    }
  }
  function collectExtras() {
    const out = [];
    for (const on of document.querySelectorAll('#extraDeals [data-xon]')) {
      const deal = on.dataset.xon;
      if (!on.checked || deal === form.deal.value) continue;
      const v = (k) => { const el = document.querySelector(`[data-xd="${deal}"][data-xk="${k}"]`); return el ? parseNum(el.value) : null; };
      out.push(isMonthly(deal) ? { deal, price: v('price') ?? 0, rent: v('rent') } : { deal, price: v('price') });
    }
    return out;
  }

  function onDeal() {
    syncExtras();
    const rent = form.deal.value === '월세' || form.deal.value === '단기';
    $('lbRent').style.visibility = rent ? '' : 'hidden';
    $('lbPriceTxt').textContent = form.deal.value === '매매' ? '매매가' : form.deal.value === '전세' ? '전세금' : '보증금';
  }
  // 숫자 칸: 숫자·점만 남기고(쉼표·글자 자동 삭제), 소수 자리수 제한 (가격 1자리 = 천원, 면적 2자리)
  // 정수 칸(방 수 등)은 점을 지우지 않음 → "2.5"가 "25"로 바뀌는 사고 방지, 저장할 때 안내
  function cleanNum(el) {
    const d = el.dataset.dec ? Number(el.dataset.dec) : (DECIMALS[el.name] || 0);
    let v = el.value.replace(/[^0-9.]/g, '');
    const i = v.indexOf('.');
    if (i >= 0) v = v.slice(0, i + 1) + v.slice(i + 1).replace(/\./g, '').slice(0, d || undefined);
    if (v !== el.value) el.value = v;
  }
  form.deal.addEventListener('change', onDeal);
  form.addEventListener('input', (e) => {
    S.dirty = true;
    if (NUM.includes(e.target.name) || e.target.dataset.xd) cleanNum(e.target);
  });
  form.addEventListener('change', (e) => {
    S.dirty = true;
    if (e.target.dataset.xon) {
      syncExtras();
      if (e.target.checked) { const first = document.querySelector(`[data-xd="${e.target.dataset.xon}"]`); if (first) first.focus(); }
    }
  });

  function collect() {
    const out = {};
    for (const k of TEXT) out[k] = form[k].value.trim();
    for (const k of NUM) out[k] = parseNum(form[k].value);
    if (out.deal !== '월세' && out.deal !== '단기') out.rent = null;
    out.extra_deals = collectExtras();
    return out;
  }
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (S.busy) return;
    const data = collect();
    if (!data.title) { toast('매물 제목을 입력해 주세요', true); form.title.focus(); return; }
    const bad = NUM.find((k) => Number.isNaN(data[k]));
    if (bad) { toast(`${NUM_LABEL[bad]} 칸에는 숫자만 입력해 주세요`, true); form[bad].focus(); return; }
    const notInt = NUM.find((k) => !DECIMALS[k] && data[k] != null && !Number.isInteger(data[k]));
    if (notInt) { toast(`${NUM_LABEL[notInt]}는 소수점 없이 입력해 주세요`, true); form[notInt].focus(); return; }
    if (data.price == null) { if (!confirm('가격이 비어 있어요. 이대로 저장할까요?')) return; }
    else if ((data.deal === '월세' || data.deal === '단기') && data.rent == null) { if (!confirm('월세가 비어 있어요. 이대로 저장할까요?')) return; }
    for (const x of data.extra_deals) {
      const need = isMonthly(x.deal) ? 'rent' : 'price';
      const el = document.querySelector(`[data-xd="${x.deal}"][data-xk="${need}"]`);
      if (Number.isNaN(x.price) || Number.isNaN(x.rent)) { toast(`추가 거래 "${x.deal}" 금액에는 숫자만 입력해 주세요`, true); el && el.focus(); return; }
      if (x[need] == null) { toast(`"${x.deal}도 가능"을 체크했다면 ${x.deal === '단기' ? '월 임대료를' : x.deal === '월세' ? '월세를' : '금액을'} 입력해 주세요`, true); el && el.focus(); return; }
    }
    S.busy = true;
    $('saveBtn').disabled = true;
    const isNew = !(S.edit && S.edit.id);
    try {
      let id = S.edit && S.edit.id;
      if (id) await api(`/api/admin/listings/${id}`, { method: 'PUT', body: data });
      else id = (await api('/api/admin/listings', { method: 'POST', body: data })).id;
      if (S.pending.length) await uploadPending(id);
      S.dirty = false;
      toast(isNew ? (data.status === '거래가능' || data.status === '계약진행중' ? `등록했어요 (매물번호 ${id}) — 손님 사이트에 바로 올라갔어요. 다음 매물을 입력하세요` : `등록했어요 (매물번호 ${id}, 상태 "${data.status}" — 손님 사이트에는 안 보여요)`) : '수정했어요 — 손님 사이트에 바로 반영돼요');
      await loadList();
      if (isNew) {
        // 새 매물 등록 후: 적었던 내용을 모두 지운 빈 등록 화면 (다음 매물 바로 입력)
        openEditor(null);
        document.querySelectorAll('.side .nav[data-view]').forEach((b) => b.classList.toggle('on', b.dataset.view === 'new'));
        window.scrollTo(0, 0);
        form.title.focus();
      } else {
        openEditor(S.items.find((x) => x.id === id)); // 수정은 고친 내용을 그대로 보여줌
      }
      S.view = 'edit';
    } catch (ex) {
      toast(ex.message, true);
    } finally {
      S.busy = false;
      $('saveBtn').disabled = false;
    }
  });
  $('cancelBtn').addEventListener('click', () => show('list'));
  $('delBtn').addEventListener('click', () => S.edit && delListing(S.edit.id));
  $('copyLink').addEventListener('click', () => {
    if (!S.edit) return;
    if (!custBase()) return toast('admin/js/config.js 에 CUSTOMER_SITE_URL 을 넣으면 링크를 복사할 수 있어요', true);
    copy(`${custBase()}/?id=${encodeURIComponent(S.edit.id)}`, '손님용 매물 링크를 복사했어요');
  });
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's' && S.view === 'edit') { e.preventDefault(); form.requestSubmit(); }
  });
  // 입력 칸에서 Enter = 다음 칸으로 이동 (저장은 [저장하기] 버튼 또는 Ctrl+S 로만)
  // - 설명(긴 글) 칸은 Enter 로 줄바꿈이 되어야 하므로 제외
  // - 한글 입력 중(조합 중) Enter 는 글자 확정용이라 건드리지 않음
  // - 버튼으로는 이동하지 않음 (버튼에서 Enter 를 누르면 저장·삭제가 눌릴 수 있어서)
  form.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || e.isComposing || e.keyCode === 229 || e.ctrlKey || e.metaKey || e.altKey) return;
    const t = e.target;
    if (!(t.tagName === 'SELECT' || (t.tagName === 'INPUT' && !['submit', 'button', 'file'].includes(t.type)))) return;
    e.preventDefault();
    const fields = [...form.querySelectorAll('input, select, textarea')].filter((el) =>
      !el.disabled && el.type !== 'hidden' && el.type !== 'file' && el.tabIndex >= 0 && el.offsetParent !== null);
    const next = fields[fields.indexOf(t) + 1];
    if (next) { next.focus(); if (next.select && next.tagName === 'INPUT' && /^(text|search|tel|url|email|number)$/.test(next.type)) next.select(); }
  });
  window.addEventListener('beforeunload', (e) => { if (S.view === 'edit' && (S.dirty || S.busy)) { e.preventDefault(); e.returnValue = ''; } });

  // ---------- 사진: 압축 + 워터마크 ----------
  async function decode(file) {
    try { return await createImageBitmap(file, { imageOrientation: 'from-image' }); } catch { /* 아래 방법으로 재시도 */ }
    const url = URL.createObjectURL(file);
    try {
      const img = new Image();
      img.src = url;
      await img.decode();
      return img;
    } catch {
      throw new Error(`"${file.name}" 사진을 열 수 없어요. (HEIC 사진이면 JPG로 바꿔서 올려주세요)`);
    } finally { URL.revokeObjectURL(url); }
  }
  function watermark(ctx, w, h) {
    const text = A.WATERMARK || '하우지';
    const fs = Math.max(14, Math.round(Math.max(w, h) / 30)); // 가로·세로 사진 모두 같은 크기로
    ctx.save();
    ctx.font = `700 ${fs}px 'Pretendard Variable', 'Apple SD Gothic Neo', 'Malgun Gothic', sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(255,255,255,0.24)';
    ctx.strokeStyle = 'rgba(0,0,0,0.10)';
    ctx.lineWidth = Math.max(1, fs / 16);
    ctx.translate(w / 2, h / 2);
    ctx.rotate(-Math.PI / 7);
    const tw = ctx.measureText(text).width;
    const sx = tw + fs * 4, sy = fs * 4.2, R = Math.hypot(w, h) / 2 + sx;
    let row = 0;
    for (let y = -R; y < R; y += sy, row++) {
      for (let x = -R + (row % 2 ? sx / 2 : 0); x < R; x += sx) { ctx.strokeText(text, x, y); ctx.fillText(text, x, y); }
    }
    ctx.restore();
    // 오른쪽 아래 선명한 표시
    ctx.save();
    const cf = Math.max(13, Math.round(Math.max(w, h) / 34));
    ctx.font = `800 ${cf}px 'Pretendard Variable', 'Apple SD Gothic Neo', 'Malgun Gothic', sans-serif`;
    ctx.textAlign = 'right';
    ctx.textBaseline = 'bottom';
    ctx.shadowColor = 'rgba(0,0,0,0.55)';
    ctx.shadowBlur = cf / 2.5;
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.fillText(text, w - cf * 0.8, h - cf * 0.6);
    ctx.restore();
  }
  // 긴 변을 maxSide에 맞춰 줄임 (자르지 않음). 4000×3000 → 1400×1050, 3000×4000 → 1050×1400
  function render(src, maxSide) {
    const sw = src.width, sh = src.height;
    const scale = Math.min(1, maxSide / Math.max(sw, sh));
    const w = Math.round(sw * scale), h = Math.round(sh * scale);
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const ctx = c.getContext('2d');
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(src, 0, 0, w, h);
    watermark(ctx, w, h);
    return c;
  }
  async function toBlob(canvas, q) {
    let b = await new Promise((r) => canvas.toBlob(r, 'image/webp', q));
    if (!b || b.type !== 'image/webp') b = await new Promise((r) => canvas.toBlob(r, 'image/jpeg', q)); // WebP 미지원 브라우저
    if (!b) throw new Error('사진 변환에 실패했어요');
    return b;
  }
  async function processImage(file) {
    const src = await decode(file);
    const full = await toBlob(render(src, A.FULL_MAX || 1400), A.FULL_QUALITY || 0.8);
    const thumb = await toBlob(render(src, A.THUMB_MAX || 600), A.THUMB_QUALITY || 0.72);
    if (src.close) src.close();
    return { full, thumb };
  }
  async function uploadOne(listingId, file) {
    const { full, thumb } = await processImage(file);
    const fd = new FormData();
    fd.append('full', full, full.type === 'image/webp' ? 'full.webp' : 'full.jpg');
    fd.append('thumb', thumb, thumb.type === 'image/webp' ? 'thumb.webp' : 'thumb.jpg');
    return (await api(`/api/admin/listings/${listingId}/photos`, { method: 'POST', form: fd })).id;
  }
  async function uploadFiles(listingId, files) {
    let done = 0, failed = 0;
    const prog = $('progress');
    for (const f of files) {
      prog.textContent = `사진 올리는 중… ${done + failed + 1} / ${files.length}`;
      try {
        const id = await uploadOne(listingId, f);
        if (S.edit && S.edit.id === listingId) S.edit.photos.push(id);
        done++;
        renderPhotos();
      } catch (e) { failed++; toast(e.message, true); }
    }
    prog.textContent = '';
    if (done) toast(`사진 ${done}장을 올렸어요${failed ? ` (실패 ${failed}장)` : ''}`, !!failed);
    return { done, failed };
  }
  async function uploadPending(id) {
    const files = S.pending.map((p) => p.file);
    clearPending();
    S.edit = S.edit || { id, photos: [] };
    await uploadFiles(id, files);
  }
  function clearPending() { for (const p of S.pending) URL.revokeObjectURL(p.url); S.pending = []; }

  async function addFiles(list) {
    const files = [...list].filter((f) => f.type.startsWith('image/') || /\.(heic|heif)$/i.test(f.name));
    if (!files.length) return;
    const total = (S.edit ? S.edit.photos.length : 0) + S.pending.length + files.length;
    if (total > 30) { toast('매물 1개당 사진은 30장까지예요', true); return; }
    if (S.edit && S.edit.id) {
      S.busy = true;
      try { await uploadFiles(S.edit.id, files); loadListQuiet(); } finally { S.busy = false; }
    } else {
      for (const f of files) S.pending.push({ file: f, url: URL.createObjectURL(f) });
      S.dirty = true;
      renderPhotos();
      toast('"등록하기"를 누르면 사진이 함께 올라가요');
    }
  }
  async function loadListQuiet() { try { S.items = (await api('/api/admin/listings')).items; } catch { /* 무시 */ } }

  function renderPhotos() {
    const saved = S.edit ? S.edit.photos : [];
    const html = saved.map((id, i) => `
      <div class="ph"><img src="/api/admin/photo/${esc(id)}?s=t" alt="">${i === 0 ? '<span class="tagm">대표</span>' : ''}
        <div class="ctl"><span><button type="button" data-mv="${i}" data-dir="-1" title="앞으로">◀</button> <button type="button" data-mv="${i}" data-dir="1" title="뒤로">▶</button></span>
        <button type="button" class="del" data-delph="${esc(id)}" title="사진 삭제">✕</button></div></div>`).join('')
      + S.pending.map((p, i) => `<div class="ph"><img src="${p.url}" alt=""><span class="tagm wait">대기</span>
        <div class="ctl"><span></span><button type="button" class="del" data-delpend="${i}" title="빼기">✕</button></div></div>`).join('');
    $('photos').innerHTML = html;
    const n = saved.length + S.pending.length;
    $('phCount').textContent = n ? `${n}장` : '';
  }
  async function movePhoto(i, dir) {
    const arr = S.edit.photos.slice();
    const j = i + dir;
    if (j < 0 || j >= arr.length) return;
    [arr[i], arr[j]] = [arr[j], arr[i]];
    try {
      await api(`/api/admin/listings/${S.edit.id}/photos/order`, { method: 'PUT', body: { ids: arr } });
      S.edit.photos = arr;
      renderPhotos();
    } catch (e) { toast(e.message, true); }
  }
  async function deletePhoto(id) {
    if (!confirm('이 사진을 삭제할까요? (구글 드라이브 휴지통으로 이동)')) return;
    try {
      const r = await api(`/api/admin/photos/${id}`, { method: 'DELETE' });
      S.edit.photos = S.edit.photos.filter((x) => x !== id);
      renderPhotos();
      toast(r.driveWarning || '사진을 삭제했어요', !!r.driveWarning);
    } catch (e) { toast(e.message, true); }
  }
  const drop = $('drop');
  drop.addEventListener('click', () => $('files').click());
  drop.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); $('files').click(); } });
  $('files').addEventListener('change', (e) => { addFiles(e.target.files); e.target.value = ''; });
  drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('over'));
  drop.addEventListener('drop', (e) => { e.preventDefault(); drop.classList.remove('over'); addFiles(e.dataTransfer.files); });

  // ---------- 문의 ----------
  // 장난·도배 대비 스위치
  async function loadGuard() {
    try {
      const g = await api('/api/admin/guard');
      $('swShare').checked = g.shareLog; $('swSite').checked = g.siteInquiry;
      $('guardSum').textContent = `· 카톡·인스타 기록 ${g.shareLog ? '켜짐' : '꺼짐'} · 사이트 문의 ${g.siteInquiry ? '켜짐' : '꺼짐'} · 확인 안 한 카톡·인스타 기록 ${g.shareCount}건`;
      if (!g.shareLog || !g.siteInquiry) $('guardBox').open = true; // 꺼진 게 있으면 펼쳐서 보이게
    } catch (e) { toast(e.message, true); }
  }
  async function setGuard(body) {
    try { await api('/api/admin/guard', { method: 'PUT', body }); toast('저장했어요'); } catch (e) { toast(e.message, true); }
    loadGuard();
  }
  async function loadInq() {
    loadGuard();
    try {
      S.inq = (await api('/api/admin/inquiries')).items;
      renderInq();
    } catch (e) { toast(e.message, true); }
  }
  function renderInq() {
    const counts = Object.fromEntries(INQ.map((s) => [s, S.inq.filter((x) => x.status === s).length]));
    const siteNew = S.inq.filter((x) => x.status === '신규' && (x.channel || '사이트') === '사이트').length;
    $('inqBadge').textContent = siteNew ? String(siteNew) : ''; // 알림 숫자는 사이트 문의만 (카톡·인스타는 그 앱이 알려줌)
    $('inqTabs').innerHTML = [['', `전체 ${S.inq.length}`], ...INQ.map((s) => [s, `${s} ${counts[s]}`])]
      .map(([k, l]) => `<button class="${S.inqTab === k ? 'on' : ''}" data-it="${k}">${l}</button>`).join('');
    const list = S.inq.filter((x) => !S.inqTab || x.status === S.inqTab);
    $('inqRows').innerHTML = list.length ? list.map((x) => {
      const phone = String(x.phone || '');
      const pretty = phone.length === 11 ? `${phone.slice(0, 3)}-${phone.slice(3, 7)}-${phone.slice(7)}` : phone;
      return `<tr>
        <td class="t-sub" style="white-space:nowrap">${kst(x.created_at)}</td>
        <td><select class="status" data-iq="${esc(x.id)}" data-v="${esc(x.status)}">${INQ.map((s) => `<option ${s === x.status ? 'selected' : ''}>${s}</option>`).join('')}</select></td>
        <td class="who">${whoCell(x, phone, pretty)}</td>
        <td>${x.listing_id ? `<a href="#" data-goedit="${esc(x.listing_id)}">${esc(x.listing_title || x.listing_id)}</a><div class="t-sub">${esc(x.listing_id)}</div>` : '<span class="t-sub">-</span>'}</td>
        <td class="t-sub">${[x.region && `지역: ${esc(x.region)}`, x.budget && `예산: ${esc(x.budget)}`, x.move_in && `입주: ${esc(x.move_in)}`].filter(Boolean).join('<br>') || '-'}</td>
        <td class="msgcell">${esc(x.message) || '<span class="t-sub">-</span>'}</td>
        <td><textarea class="memo" data-memo="${esc(x.id)}" placeholder="통화 결과 등">${esc(x.admin_memo || '')}</textarea></td>
        <td><button class="btn sm danger" data-delinq="${esc(x.id)}">삭제</button></td></tr>`;
    }).join('') : '<tr><td colspan="8" class="empty">문의가 없어요.</td></tr>';
  }
  // 경로 · 이름 · 연락처 칸 (카톡·인스타 손님은 운영자가 대화한 뒤 이름·연락처를 적어 둘 수 있음)
  const CH_CLASS = { 카톡: 'kakao', 인스타: 'insta', 전화: 'phone', 기타: 'etc' };
  const CHANNELS = ['사이트', '카톡', '인스타', '전화', '기타'];
  function whoCell(x, phone, pretty) {
    const ch = x.channel || '사이트';
    const tag = `<span class="ch ch-${CH_CLASS[ch] || 'site'}">${esc(ch)}</span>`;
    if (S.editWho === x.id) {
      return `${tag}<div class="who-edit">
        <label>경로<select data-who-ch>${CHANNELS.map((c) => `<option ${c === ch ? 'selected' : ''}>${c}</option>`).join('')}</select></label>
        <label>이름 · 닉네임<input data-who-name value="${esc(x.name || '')}" maxlength="30"></label>
        <label>연락처 · 아이디<input data-who-phone value="${esc(phone)}" maxlength="50"></label>
        <div><button class="btn sm primary" data-who-save="${esc(x.id)}">저장</button> <button class="btn sm" data-who-cancel>취소</button></div></div>`;
    }
    const isTel = /^[0-9+\-\s()]{8,}$/.test(phone);
    const share = ch === '카톡' || ch === '인스타';
    const name = x.name ? `<b>${esc(x.name)}</b>` : `<span class="t-sub">${share ? '이름 미입력' : '(이름 없음)'}</span>`;
    const contact = phone
      ? (isTel ? `<a href="tel:${esc(phone.replace(/[^0-9+]/g, ''))}">${esc(pretty)}</a>` : `<span>${esc(phone)}</span>`) + ` <button class="btn sm" data-cp="${esc(isTel ? pretty : phone)}">복사</button>`
      : (share ? `<span class="t-sub">${esc(ch)} 대화방에서 확인</span>` : '');
    return `${tag}<div>${name}</div><div>${contact}</div><button class="btn sm ghost who-btn" data-who="${esc(x.id)}">✎ ${x.name || phone ? '수정' : '이름·연락처 적기'}</button>`;
  }
  async function updInq(id, body) {
    try {
      await api(`/api/admin/inquiries/${id}`, { method: 'PUT', body });
      const x = S.inq.find((i) => i.id === id);
      Object.assign(x, body);
      if ('status' in body || 'name' in body || 'phone' in body || 'channel' in body) renderInq();
      toast('저장했어요');
    } catch (e) { toast(e.message, true); }
  }
  // ---------- 새 문의 알림 ----------
  // ① 이 화면을 켜두면 30초마다 확인 → 소리 + 화면 알림 + 탭 제목 "(1) 새 문의"
  // ② 웹 푸시: 화면을 닫아도 휴대폰·PC 알림 (아이폰은 "홈 화면에 추가" 후 그 아이콘으로 열어야 켤 수 있음)
  const BASE_TITLE = document.title;
  let lastLatest = null;
  let audio = null;
  // 브라우저는 화면을 한 번 누르기 전엔 소리를 막아서, 첫 클릭 때 소리 장치를 준비
  document.addEventListener('pointerdown', () => {
    try {
      if (!audio) audio = new (window.AudioContext || window.webkitAudioContext)();
      else if (audio.state === 'suspended') audio.resume();
    } catch { /* 소리 없이 계속 */ }
  }, { passive: true });
  function beep() {
    if (!audio) return;
    const t = audio.currentTime;
    [[0, 880], [0.2, 1175]].forEach(([d, f]) => {
      const o = audio.createOscillator(), g = audio.createGain();
      o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, t + d);
      g.gain.exponentialRampToValueAtTime(0.35, t + d + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.18);
      o.connect(g).connect(audio.destination);
      o.start(t + d); o.stop(t + d + 0.2);
    });
  }
  async function checkNew() {
    try {
      const d = await api('/api/admin/inquiries/summary');
      $('inqBadge').textContent = d.newCount ? String(d.newCount) : '';
      document.title = d.newCount ? `(${d.newCount}) 새 문의 · ${BASE_TITLE}` : BASE_TITLE;
      if (lastLatest !== null && d.latest && d.latest > lastLatest) {
        beep();
        toast('새 문의가 들어왔어요!');
        if (S.view === 'inq') loadInq();
        // 이 기기에 휴대폰 알림(②)이 꺼져 있고 다른 탭을 보고 있을 때만 PC 화면 알림
        if (document.hidden && !PUSH.sub && 'Notification' in window && Notification.permission === 'granted') {
          try { const n = new Notification('하우지 새 문의', { body: '문의 목록에서 확인해 주세요.' }); n.onclick = () => { window.focus(); show('inq'); n.close(); }; } catch { /* 무시 */ }
        }
      }
      lastLatest = d.latest || '';
    } catch { /* 로그인 만료 등은 api()가 안내 */ }
  }

  // 새 문의 확인 주기 (Cloudflare 무료 한도: 하루 서버 요청 10만 건을 손님 사이트와 같이 씀)
  //   화면을 보고 있을 때: 30초마다
  //   다른 탭·최소화: 이 기기에 휴대폰 알림(웹 푸시)이 켜져 있으면 멈춤(알림은 푸시로 옴), 꺼져 있으면 2분마다
  //   다시 화면으로 돌아오면 바로 1번 확인
  let pollTimer = null;
  function startPolling() {
    clearInterval(pollTimer);
    pollTimer = null;
    if (!document.hidden) pollTimer = setInterval(checkNew, 30_000);
    else if (!PUSH.sub) pollTimer = setInterval(checkNew, 120_000);
  }
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) checkNew();
    startPolling();
  });

  const PUSH = { reg: null, sub: null, key: '', devices: 0, busy: false };
  const isIOS = /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const standalone = () => window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  const pushOk = () => 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
  const keyBytes = (s) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/')), (c) => c.charCodeAt(0));
  async function initPush() {
    if ('serviceWorker' in navigator) {
      try {
        PUSH.reg = await navigator.serviceWorker.register('/sw.js');
        if (PUSH.reg.pushManager) PUSH.sub = await PUSH.reg.pushManager.getSubscription();
      } catch { /* 지원 안 함 */ }
    }
    try { const d = await api('/api/admin/push'); PUSH.key = d.key; PUSH.devices = d.devices; } catch { /* 무시 */ }
    renderNotif();
  }
  function renderNotif() {
    const box = $('notifBox');
    const sound = '<p class="note">이 화면을 켜두면 30초마다(다른 탭을 보고 있으면 2분마다) 확인해서 소리로도 알려드려요. (소리는 화면을 한 번 누른 뒤부터 나요)</p>';
    let html;
    if (isIOS && !standalone()) {
      html = `<b>📱 아이폰에서 새 문의 알림 받기</b>
        <ol><li>사파리 아래쪽 <b>공유 버튼(□↑)</b> → <b>홈 화면에 추가</b></li>
        <li>홈 화면에 생긴 <b>'하우지 운영'</b> 아이콘으로 열기 (로그인 한 번 더 필요할 수 있어요)</li>
        <li>문의 목록에서 <b>[이 기기에서 알림 켜기]</b> → <b>허용</b></li></ol>
        <p class="note">아이폰은 iOS 16.4 이상, 홈 화면 아이콘으로 열었을 때만 알림을 켤 수 있어요.</p>`;
    } else if (!pushOk()) {
      html = '<b>이 브라우저는 휴대폰 알림을 지원하지 않아요.</b>' + sound;
    } else if (Notification.permission === 'denied') {
      html = `<b>알림이 차단돼 있어요.</b><p class="note">${isIOS ? '아이폰 설정 → 알림 → 하우지 운영 → 알림 허용' : '주소창 왼쪽 자물쇠 → 알림 → 허용'} 후 이 화면을 새로고침해 주세요.</p>`;
    } else if (PUSH.sub) {
      html = `<b>✅ 이 기기에서 새 문의 알림이 켜져 있어요</b> <span class="t-sub">(알림 받는 기기 ${PUSH.devices}대)</span>
        <div class="row"><button class="btn sm" id="pushTest" type="button">테스트 알림 보내기</button><button class="btn sm" id="pushOff" type="button">이 기기 알림 끄기</button></div>` + sound;
    } else {
      html = `<b>🔔 새 문의가 오면 이 기기로 알림 받기</b> <span class="t-sub">(지금 알림 받는 기기 ${PUSH.devices}대)</span>
        <div class="row"><button class="btn primary sm" id="pushOn" type="button">이 기기에서 알림 켜기</button></div>
        <p class="note">휴대폰 화면을 꺼두거나 이 사이트를 닫아도 알림이 와요. 잠금화면에는 연락처가 보이지 않아요.</p>` + sound;
    }
    box.innerHTML = html;
  }
  async function pushOn() {
    if (PUSH.busy) return;
    PUSH.busy = true;
    try {
      const perm = await Notification.requestPermission(); // 아이폰은 버튼을 누른 순간에 바로 물어봐야 함
      if (perm !== 'granted') { toast('알림을 허용해야 받을 수 있어요', true); return; }
      if (!PUSH.reg) PUSH.reg = await navigator.serviceWorker.register('/sw.js');
      await navigator.serviceWorker.ready;
      if (!PUSH.key) PUSH.key = (await api('/api/admin/push')).key;
      PUSH.sub = await PUSH.reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: keyBytes(PUSH.key) });
      const label = isIOS ? '아이폰' : /Android/.test(navigator.userAgent) ? '안드로이드' : 'PC';
      PUSH.devices = (await api('/api/admin/push/subscribe', { method: 'POST', body: { ...PUSH.sub.toJSON(), label } })).devices;
      toast('알림을 켰어요. [테스트 알림 보내기]로 확인해 보세요');
    } catch (e) {
      toast(`알림을 켜지 못했어요: ${e.message}`, true);
    } finally { PUSH.busy = false; renderNotif(); }
  }
  async function pushOff() {
    try {
      const ep = PUSH.sub && PUSH.sub.endpoint;
      if (PUSH.sub) await PUSH.sub.unsubscribe();
      PUSH.sub = null;
      if (ep) PUSH.devices = (await api('/api/admin/push/unsubscribe', { method: 'POST', body: { endpoint: ep } })).devices;
      toast('이 기기 알림을 껐어요');
    } catch (e) { toast(e.message, true); }
    renderNotif();
  }
  async function pushTest() {
    try {
      const r = await api('/api/admin/push/test', { method: 'POST' });
      toast(r.sent ? `알림 ${r.sent}대에 보냈어요${r.failed ? ` (실패 ${r.failed}대)` : ''}` : '알림을 보내지 못했어요. 알림을 다시 켜주세요', !r.sent);
      PUSH.devices = r.total - (r.failed || 0);
      renderNotif();
    } catch (e) { toast(e.message, true); }
  }
  document.addEventListener('click', (e) => {
    if (e.target.closest('#pushOn')) pushOn();
    else if (e.target.closest('#pushOff')) pushOff();
    else if (e.target.closest('#pushTest')) pushTest();
  });
  window.addEventListener('hashchange', () => { if (location.hash === '#inq') show('inq'); });

  // ---------- 백업 ----------
  const csvCell = (v) => { const s = String(v ?? ''); return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const toCsv = (rows, cols) => '﻿' + [cols.map((c) => c[1]).join(','), ...rows.map((r) => cols.map((c) => csvCell(typeof c[0] === 'function' ? c[0](r) : r[c[0]])).join(','))].join('\r\n');
  $('dlListCsv').addEventListener('click', async () => {
    await loadListQuiet();
    const cols = [['id', '매물번호'], ['status', '상태'], ['title', '제목'], ['deal', '거래'], ['ptype', '종류'], ['sido', '시도'], ['gu', '구군'], ['dong', '동'], ['unit', '동호수(비공개)'],
      ['price', '보증금/매매가(만원)'], ['rent', '월세(만원)'], ['maint', '관리비(만원)'], [(r) => extraText(r), '추가 거래'], ['area', '전용㎡'], ['supply_area', '공급㎡'], ['rooms', '방'], ['baths', '욕실'], ['floor', '층'], ['total_floors', '총층'],
      ['move_in', '입주가능일'], ['parking', '주차'], ['direction', '방향'], ['approval_date', '사용승인일'], ['pet', '반려동물'], ['tags', '키워드'], ['description', '설명'],
      ['owner_contact', '임대인연락처(비공개)'], ['memo', '메모(비공개)'], ['views', '조회수'], [(r) => r.photos.length, '사진수'], [(r) => kst(r.created_at), '등록'], [(r) => kst(r.updated_at), '수정']];
    download(`하우지_매물_${today()}.csv`, toCsv(S.items, cols), 'text/csv;charset=utf-8');
  });
  $('dlListJson').addEventListener('click', async () => {
    await loadListQuiet();
    download(`하우지_매물백업_${today()}.json`, JSON.stringify({ exported_at: new Date().toISOString(), items: S.items }, null, 2), 'application/json');
  });
  $('dlInqCsv').addEventListener('click', async () => {
    try { S.inq = (await api('/api/admin/inquiries')).items; } catch (e) { return toast(e.message, true); }
    const cols = [[(r) => kst(r.created_at), '접수'], ['status', '상태'], [(r) => r.channel || '사이트', '경로'], ['name', '이름'], ['phone', '연락처'], ['listing_id', '매물번호'], ['listing_title', '매물'],
      ['region', '희망지역'], ['budget', '예산'], ['move_in', '입주'], ['message', '내용'], ['admin_memo', '메모']];
    download(`하우지_문의_${today()}.csv`, toCsv(S.inq, cols), 'text/csv;charset=utf-8');
  });

  // ---------- 사이트 상태 점검 ----------
  $('healthBtn').addEventListener('click', async () => {
    const box = $('healthOut');
    box.innerHTML = '<p class="note">점검 중…</p>';
    try {
      const d = await api('/api/admin/health');
      const bad = d.checks.filter((c) => !c.ok).length;
      box.innerHTML = `<p><b>${bad ? `⚠ 확인 필요 ${bad}개` : '✅ 모두 정상'}</b> <span class="t-sub">${esc(kst(d.at))} 점검</span></p>`
        + `<table class="health"><tbody>${d.checks.map((c) => `<tr><td>${c.ok ? '✅' : '⚠'}</td><td><b>${esc(c.name)}</b></td><td>${esc(c.detail)}</td></tr>`).join('')}</tbody></table>`;
    } catch (e) { box.innerHTML = `<p class="note">⚠ ${esc(e.message)}</p>`; }
  });

  // ---------- 이벤트 ----------
  document.addEventListener('click', (e) => {
    const t = e.target;
    const nav = t.closest('[data-view]');
    if (nav) { show(nav.dataset.view); return; }
    const fs = t.closest('[data-fs]');
    if (fs) { S.filterStatus = fs.dataset.fs; renderList(); return; }
    const ed = t.closest('[data-edit]');
    if (ed) { const l = S.items.find((x) => x.id === ed.dataset.edit); if (l && show('edit')) openEditor(l); return; }
    const goed = t.closest('[data-goedit]');
    if (goed) {
      e.preventDefault();
      const l = S.items.find((x) => x.id === goed.dataset.goedit);
      if (!l) { toast('삭제된 매물이에요', true); return; }
      if (show('edit')) openEditor(l);
      return;
    }
    const ln = t.closest('[data-link]');
    if (ln) {
      if (!custBase()) { toast('admin/js/config.js 에 CUSTOMER_SITE_URL 을 넣으면 링크를 복사할 수 있어요', true); return; }
      copy(`${custBase()}/?id=${encodeURIComponent(ln.dataset.link)}`, '손님용 매물 링크를 복사했어요');
      return;
    }
    const del = t.closest('[data-del]');
    if (del) { delListing(del.dataset.del); return; }
    const mv = t.closest('[data-mv]');
    if (mv) { movePhoto(Number(mv.dataset.mv), Number(mv.dataset.dir)); return; }
    const dph = t.closest('[data-delph]');
    if (dph) { deletePhoto(dph.dataset.delph); return; }
    const dpend = t.closest('[data-delpend]');
    if (dpend) { const p = S.pending.splice(Number(dpend.dataset.delpend), 1)[0]; if (p) URL.revokeObjectURL(p.url); renderPhotos(); return; }
    const it = t.closest('[data-it]');
    if (it) { S.inqTab = it.dataset.it; renderInq(); return; }
    const cp = t.closest('[data-cp]');
    if (cp) { copy(cp.dataset.cp, '연락처를 복사했어요'); return; }
    const whoBtn = t.closest('[data-who]');
    if (whoBtn) { S.editWho = whoBtn.dataset.who; renderInq(); return; }
    if (t.closest('[data-who-cancel]')) { S.editWho = null; renderInq(); return; }
    const whoSave = t.closest('[data-who-save]');
    if (whoSave) {
      const box = whoSave.closest('.who-edit');
      const body = { channel: box.querySelector('[data-who-ch]').value, name: box.querySelector('[data-who-name]').value.trim(), phone: box.querySelector('[data-who-phone]').value.trim() };
      S.editWho = null;
      updInq(whoSave.dataset.whoSave, body);
      return;
    }
    const di = t.closest('[data-delinq]');
    if (di) {
      if (!confirm('이 문의를 삭제할까요? 되돌릴 수 없어요.')) return;
      api(`/api/admin/inquiries/${di.dataset.delinq}`, { method: 'DELETE' }).then(() => { S.inq = S.inq.filter((x) => x.id !== di.dataset.delinq); renderInq(); toast('삭제했어요'); }, (er) => toast(er.message, true));
    }
  });
  document.addEventListener('change', (e) => {
    const st = e.target.closest('[data-st]');
    if (st) { setStatus(st.dataset.st, st.value, st); return; }
    const iq = e.target.closest('[data-iq]');
    if (iq) { iq.dataset.v = iq.value; updInq(iq.dataset.iq, { status: iq.value }); return; }
    const memo = e.target.closest('[data-memo]');
    if (memo) updInq(memo.dataset.memo, { admin_memo: memo.value });
  });
  $('q').addEventListener('input', renderList);
  $('qDeal').addEventListener('change', renderList);
  $('reload').addEventListener('click', loadList);
  $('inqReload').addEventListener('click', loadInq);
  $('swShare').addEventListener('change', (e) => setGuard({ shareLog: e.target.checked }));
  $('swSite').addEventListener('change', (e) => setGuard({ siteInquiry: e.target.checked }));
  $('clearShare').addEventListener('click', async () => {
    if (!window.confirm('확인 안 한 카톡·인스타 기록(이름·연락처·메모 없음)을 지울까요? 사이트 문의와 이름·연락처를 적은 기록은 남아요. 지운 기록은 되돌릴 수 없어요.')) return;
    try { await api('/api/admin/inquiries/share-logs', { method: 'DELETE' }); toast('확인 안 한 카톡·인스타 기록을 지웠어요'); } catch (e) { toast(e.message, true); }
    loadInq();
  });

  // ---------- 로그아웃: 이 기기의 로그인 쿠키를 지우고 로그인 화면으로 ----------
  $('logoutLink').addEventListener('click', async (ev) => {
    ev.preventDefault();
    try { await api('/api/admin/auth/logout', { method: 'POST' }); } catch (e) { toast(e.message, true); return; }
    location.replace('/');
  });

  // ---------- 시작 ----------
  (async () => {
    if (custBase()) $('custLink').href = custBase(); else $('custLink').style.display = 'none';
    // 구글 로그인에서 돌아왔을 때 결과 안내 (주소창의 ?login=... 은 바로 지움)
    const LOGIN_MSG = {
      notallowed: '운영자로 등록된 구글 계정이 아니에요. 다른 계정으로 로그인해 주세요.',
      expired: '로그인 시간이 지났어요. 다시 시도해 주세요.',
      cancel: '로그인을 취소했어요.',
      failed: '로그인에 실패했어요. 잠시 후 다시 시도해 주세요.',
    };
    const loginResult = new URLSearchParams(location.search).get('login');
    if (loginResult) history.replaceState(null, '', location.pathname + location.hash);
    try {
      const me = await api('/api/admin/me');
      $('who').textContent = me.email;
    } catch (e) {
      if (e.status === 401 || e.status === 403) showGate(LOGIN_MSG[loginResult] || (e.status === 403 ? e.message : ''));
      else $('banner').textContent = e.message;
      return;
    }
    if (location.hash === '#inq') show('inq'); else loadList(); // 알림을 누르면 문의 목록으로
    checkNew();
    startPolling();
    initPush();
  })();
})();
