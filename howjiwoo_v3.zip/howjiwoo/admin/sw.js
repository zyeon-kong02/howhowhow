/* 하우지 운영자 — 알림 담당 (서비스 워커)
   새 문의가 오면 서버가 보낸 알림을 휴대폰·PC 화면에 띄우고, 누르면 문의 목록을 엽니다. */
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

self.addEventListener('push', (e) => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch { d = {}; }
  // 아이폰은 알림을 받으면 반드시 화면에 띄워야 함 (안 띄우면 알림 권한이 꺼짐)
  e.waitUntil(self.registration.showNotification(d.title || '하우지 새 문의', {
    body: d.body || '문의 목록에서 확인해 주세요.',
    icon: '/favicon.png',
    data: { url: d.url || '/#inq' },
  }));
});

self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const url = new URL((e.notification.data && e.notification.data.url) || '/#inq', self.location.origin).href;
  e.waitUntil((async () => {
    const wins = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const w of wins) {
      if ('focus' in w) {
        await w.focus();
        if ('navigate' in w) { try { await w.navigate(url); } catch { /* 무시 */ } }
        return;
      }
    }
    await self.clients.openWindow(url);
  })());
});
