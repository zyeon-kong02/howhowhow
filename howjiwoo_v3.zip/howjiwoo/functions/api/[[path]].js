// Cloudflare Pages Functions 진입점: /api/ 로 시작하는 모든 요청을 lib/router.js 로 넘깁니다.
import { handle } from '../../lib/router.js';

export const onRequest = (context) => handle(context.request, context.env, context);
