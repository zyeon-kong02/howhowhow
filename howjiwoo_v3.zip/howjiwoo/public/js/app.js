/* 하우지 손님 사이트 동작 */
(() => {
  'use strict';
  const C = window.HOWGEE || {};
  // 화면 요소 찾기. 없으면 = 휴대폰에 예전 화면(HTML)이 남아 있고 코드(JS)만 새것인 상태
  // → 한 번 자동으로 새로고침해서 새 화면을 받음 (10분에 1번까지). 그동안 멈추지 않도록 빈 요소를 돌려줌
  const $ = (id) => document.getElementById(id) || staleElement(id);
  function staleElement(id) {
    try {
      const last = Number(sessionStorage.getItem('howgee_reloaded') || 0);
      if (Date.now() - last > 10 * 60 * 1000) {
        sessionStorage.setItem('howgee_reloaded', String(Date.now()));
        location.reload();
      }
    } catch { /* 저장 못 하는 브라우저는 새로고침 안 함 */ }
    console.warn('화면 요소 없음:', id);
    return document.createElement('div');
  }
  const TYPES = ['원룸', '투룸', '쓰리룸', '오피스텔', '아파트', '빌라', '상가'];
  const DEALS = ['월세', '전세', '매매', '단기'];
  const PRICE_RANGES = [ // 보증금·매매가 기준 (만원)
    ['~1천만', 0, 1000], ['1천~5천만', 1000, 5000], ['5천만~1억', 5000, 10000],
    ['1억~3억', 10000, 30000], ['3억~5억', 30000, 50000], ['5억 이상', 50000, Infinity],
  ];
  // 월세·단기를 고르면 가격대가 "월세 금액" 기준으로 바뀜 (만원, 양쪽 끝 포함). 바꾸려면 숫자만 고치면 됨
  const RENT_RANGES = [
    ['월 30만 이하', 0, 30], ['월 30~50만', 30, 50], ['월 50~70만', 50, 70], ['월 70~100만', 70, 100], ['월 100만 이상', 100, Infinity],
  ];
  const rentMode = () => state.deal === '월세' || state.deal === '단기';
  const ranges = () => (rentMode() ? RENT_RANGES : PRICE_RANGES);

  const state = { popular: [], items: [], deal: '', region: '', ptype: '', price: '', kw: '', sort: 'new', favOnly: false, openId: null, botIds: null, page: 1, allMode: false };
  // 한 페이지에 보여줄 매물 수 (PC 4개×3줄). 바꾸려면 숫자만 고치면 됨
  const PER_PAGE = 12;
  // 큰 모니터의 전체 매물 화면은 한 줄 5개라서 15개(5×3줄)
  const perPage = () => (state.allMode && window.matchMedia('(min-width: 1440px)').matches ? 15 : PER_PAGE);
  let lastFilterKey = '';

  // ---------- 도우미 ----------
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const icon = (n, cls = 'i') => `<svg class="${cls}"><use href="#i-${n}"/></svg>`;
  // 가격은 만원 단위 숫자 (소수 1자리 = 천원). 예: 25000 → "2억 5,000만", 45.5 → "45만 5천", 0.5 → "5천"
  function won(n) {
    n = Number(n);
    if (!Number.isFinite(n) || n <= 0) return '0';
    const t = Math.round(n * 10); // 천원 단위
    const eok = Math.floor(t / 100000), man = Math.floor((t % 100000) / 10), chun = t % 10;
    return [eok && `${eok}억`, man && `${man.toLocaleString()}만`, chun && `${chun}천`].filter(Boolean).join(' ');
  }
  // 월세·단기: "월세 1,000 / 45만 5천" (보증금은 업계 표기대로 끝의 "만" 생략)
  function priceText(l) {
    if (l.deal === '월세' || l.deal === '단기') return `${l.deal} ${l.price > 0 ? won(l.price).replace(/만$/, '') : '무보증'} / ${won(l.rent || 0)}`;
    return `${l.deal} ${won(l.price)}`;
  }
  // 거래 목록: 기본 거래 + 추가로 가능한 거래 (예: 월세 매물인데 전세·매매도 가능)
  function dealsOf(l) {
    let extra = [];
    try { extra = JSON.parse(l.extra_deals || '[]'); } catch { /* 잘못된 값은 무시 */ }
    return [{ deal: l.deal, price: l.price, rent: l.rent }, ...(Array.isArray(extra) ? extra : [])];
  }
  // 화면에 먼저 보여줄 거래: 손님이 거래 유형(예: 전세)을 골랐으면 그 거래, 아니면 기본 거래
  const mainDeal = (l) => (state.deal && dealsOf(l).find((d) => d.deal === state.deal)) || dealsOf(l)[0];
  const otherDeals = (l) => { const m = mainDeal(l); return dealsOf(l).filter((d) => d.deal !== m.deal); };
  const allPriceText = (l) => dealsOf(l).map(priceText).join(' · ');
  // 상담봇에서 끝까지 고른 조건 { text: 여러 줄, short: 한 줄 요약, region, budget, moveIn }
  // 같은 탭에서는 새로고침해도 유지. "대화 초기화"·조건 표시줄의 [지우기]로 삭제
  const botSaved = {
    get() { try { return JSON.parse(sessionStorage.getItem('howgee_bot2') || 'null'); } catch { return null; } },
    set(v) { try { v ? sessionStorage.setItem('howgee_bot2', JSON.stringify(v)) : sessionStorage.removeItem('howgee_bot2'); } catch { /* 저장 못 해도 동작에는 문제 없음 */ } },
  };
  const listingLink = (l) => `${location.origin}/?id=${encodeURIComponent(l.id)}`;
  // 카톡·인스타에 붙여넣을 글: 제목 + (고른 매물) + (상담봇 조건)
  function shareBody(kind, list, conds) {
    const head = kind === 'bot' ? '[하우지 상담 요청]' : list.length > 1 ? `[하우지 매물 ${list.length}개 문의]` : '[하우지 매물 문의]';
    const parts = [head];
    if (list.length === 1) parts.push(`${list[0].title}\n${allPriceText(list[0])}\n매물번호: ${list[0].id}\n${listingLink(list[0])}`);
    else if (list.length) parts.push(list.map((l, i) => `${i + 1}. ${l.title} (${allPriceText(l)})\n매물번호: ${l.id}\n${listingLink(l)}`).join('\n\n'));
    if (conds) parts.push(`[상담봇에서 고른 조건]\n${conds.text}`);
    return parts.join('\n\n');
  }
  const locText = (l) => [l.sido, l.gu, l.dong].filter(Boolean).join(' ');
  // 카드용 짧은 지역 (좁은 카드에서 동 이름이 잘리지 않도록 시/도는 구가 있으면 생략)
  const locShort = (l) => (l.gu || l.dong ? [l.gu, l.dong] : [l.sido]).filter(Boolean).join(' ');
  // 등록일 (한국 시간): 올해면 "11.22", 아니면 "2025.11.22"
  function regDate(iso, full = false) {
    const d = new Date(new Date(iso).getTime() + 9 * 3600000);
    const now = new Date(Date.now() + 9 * 3600000);
    const md = `${d.getUTCMonth() + 1}.${String(d.getUTCDate()).padStart(2, '0')}`;
    return full || d.getUTCFullYear() !== now.getUTCFullYear() ? `${d.getUTCFullYear()}.${String(d.getUTCMonth() + 1).padStart(2, '0')}.${String(d.getUTCDate()).padStart(2, '0')}` : md;
  }
  const isNew = (l) => Date.now() - new Date(l.created_at).getTime() < (C.NEW_DAYS || 7) * 86400000;
  const photo = (id, size) => `/api/photo/${encodeURIComponent(id)}?s=${size}`;
  function toast(msg) {
    const t = $('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toast.t);
    toast.t = setTimeout(() => t.classList.remove('show'), 2200);
  }
  // 복사 성공하면 true. done(문구)이 있으면 아래 알림도 띄움
  function copy(text, done) {
    const ok = () => { if (done !== false) toast(done || '복사했어요'); return true; };
    const fallback = () => {
      const ta = document.createElement('textarea');
      ta.value = text; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      let r = false;
      try { r = document.execCommand('copy'); } catch { r = false; }
      ta.remove();
      if (r) return ok();
      if (done !== false) toast('복사하지 못했어요');
      return false;
    };
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text).then(ok, fallback);
    return Promise.resolve(fallback());
  }

  // ---------- 찜 (이 기기 브라우저에만 저장) ----------
  const FKEY = 'howgee_fav';
  function getFav() { try { return new Set(JSON.parse(localStorage.getItem(FKEY) || '[]')); } catch { return new Set(); } }
  function setFav(s) { try { localStorage.setItem(FKEY, JSON.stringify([...s])); } catch { /* 저장 불가 브라우저 */ } }
  let fav = getFav();
  function toggleFav(id) {
    fav.has(id) ? fav.delete(id) : fav.add(id);
    setFav(fav);
    toast(fav.has(id) ? '관심매물에 담았어요 (이 기기에만 저장)' : '관심매물에서 뺐어요');
    renderFavCount();
    render();
    if (state.openId === id) openDetail(id, 'refresh');
  }
  function renderFavCount() {
    const n = state.items.length ? state.items.filter((l) => fav.has(l.id)).length : fav.size;
    $('favCount').textContent = n ? String(n) : '';
  }

  // ---------- 사진 보호 ----------
  // 화면 캡처까지 막을 수는 없지만, 우클릭·끌어서 저장·길게 눌러 저장·인쇄를 막습니다.
  // 사진 자체에도 업로드할 때 워터마크가 새겨집니다.
  document.addEventListener('contextmenu', (e) => { if (e.target.closest('.protect, .slider, .thumb')) e.preventDefault(); });
  document.addEventListener('dragstart', (e) => { if (e.target.tagName === 'IMG') e.preventDefault(); });
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && ['s', 'p'].includes(e.key.toLowerCase())) { e.preventDefault(); toast('사진 저장·인쇄는 지원하지 않아요'); }
  });

  // ---------- 카드 ----------
  function card(l, rank) {
    const thumb = l.photos && l.photos.length
      // 사진 전체가 보이도록(안 잘림) 앞에 원본, 뒤 빈 공간은 같은 사진을 흐리게 채움 (같은 주소라 한 번만 내려받음)
      ? `<img class="bg" src="${photo(l.photos[0], 't')}" alt="" aria-hidden="true" loading="lazy" decoding="async"><img class="fg" src="${photo(l.photos[0], 't')}" alt="" loading="lazy" decoding="async">`
      : `<span class="noimg">${icon('img', 'i')}</span>`;
    const badge = rank ? `<span class="badge top">인기 ${rank}위</span>`
      : l.status === '계약진행중' ? '<span class="badge ing">계약진행중</span>' : isNew(l) ? '<span class="badge">신규</span>' : '';
    const meta = [l.area ? `${icon('area')} 전용 ${Math.round(l.area)}㎡` : '', l.rooms != null ? `방 ${l.rooms}개` : '', l.total_floors ? `총 ${l.total_floors}층` : '']
      .filter(Boolean).join('<i></i>');
    const others = otherDeals(l);
    return `<article class="card" data-id="${esc(l.id)}" tabindex="0" aria-label="${esc(locText(l) + ' ' + l.ptype + ' ' + allPriceText(l))}">
      <div class="thumb protect">${thumb}${badge}</div>
      <button class="heart ${fav.has(l.id) ? 'on' : ''}" data-fav="${esc(l.id)}" aria-label="관심매물">${icon(fav.has(l.id) ? 'heart-f' : 'heart')}</button>
      <div class="body"><div class="loc" title="${esc(locText(l))}">${esc(locShort(l))} ${esc(l.ptype)}</div>
      <div class="price">${esc(priceText(mainDeal(l)))}</div>${others.length ? `<div class="price2">${esc(others.map(priceText).join(' · '))}${others.length === 1 ? '도 가능' : ' 가능'}</div>` : ''}<div class="meta">${meta}</div>
      <div class="date${isNew(l) ? ' new' : ''}">${regDate(l.created_at)} 등록</div></div></article>`;
  }

  // ---------- 필터 ----------
  function filtered() {
    const kw = state.kw.trim().toLowerCase();
    let list = state.items.filter((l) => {
      if (state.favOnly && !fav.has(l.id)) return false;
      if (state.botIds && !state.botIds.includes(l.id)) return false;
      if (state.deal && !dealsOf(l).some((d) => d.deal === state.deal)) return false;
      if (state.ptype && l.ptype !== state.ptype) return false;
      if (state.region && `${l.sido || ''} ${l.gu || ''}`.trim() !== state.region) return false;
      if (state.price !== '') {
        // 월세·단기를 골랐으면 월세 금액 기준, 아니면 보증금·매매가 기준 (경계값 포함: 딱 50만·딱 1억도 나옴)
        const r = ranges()[Number(state.price)];
        if (r) {
          const [, lo, hi] = r;
          const cands = state.deal ? [mainDeal(l)] : dealsOf(l);
          const key = rentMode() ? 'rent' : 'price';
          if (!cands.some((d) => { const p = Number(d[key] || 0); return p >= lo && p <= hi; })) return false;
        }
      }
      if (kw) {
        const hay = [l.title, l.sido, l.gu, l.dong, l.ptype, dealsOf(l).map((d) => d.deal).join(' '), l.tags, l.description, l.parking, l.direction, l.pet ? `반려동물 ${l.pet}` : '']
          .join(' ').toLowerCase();
        if (!kw.split(/\s+/).every((w) => hay.includes(w))) return false;
      }
      return true;
    });
    const sorters = {
      new: (a, b) => (a.created_at < b.created_at ? 1 : -1),
      low: (a, b) => { const x = mainDeal(a), y = mainDeal(b); return (x.price || 0) - (y.price || 0) || (x.rent || 0) - (y.rent || 0); },
      high: (a, b) => { const x = mainDeal(a), y = mainDeal(b); return (y.price || 0) - (x.price || 0) || (y.rent || 0) - (x.rent || 0); },
      area: (a, b) => (b.area || 0) - (a.area || 0),
    };
    return list.sort(sorters[state.sort] || sorters.new);
  }

  function render() {
    syncPriceOptions();
    const list = filtered();
    // 관심매물 화면이고 담은 매물이 있으면 "관심매물 전체 문의하기" 표시
    $('favAsk').hidden = !(state.favOnly && list.length);
    renderCondBar();
    // 조건·정렬이 바뀌면 1페이지로
    const fkey = [state.favOnly, state.deal, state.region, state.ptype, state.price, state.kw, state.sort, String(state.botIds)].join('|');
    if (fkey !== lastFilterKey) { state.page = 1; lastFilterKey = fkey; }
    const pages = Math.max(1, Math.ceil(list.length / perPage()));
    if (state.page > pages) state.page = pages;
    const shown = list.slice((state.page - 1) * perPage(), state.page * perPage());
    $('listTitle').innerHTML = `${icon(state.favOnly ? 'heart' : 'list', '')}${state.favOnly ? '관심매물' : '전체 매물'} <small style="color:#6b736c;font-weight:500">${list.length}개</small>`;
    $('grid').innerHTML = list.length
      ? shown.map((l) => card(l)).join('')
      : `<div class="notice" style="grid-column:1/-1">${state.favOnly ? '아직 담은 관심매물이 없어요.<br>마음에 드는 매물의 ♡를 눌러보세요.' : '조건에 맞는 매물이 없어요.<br>조건을 바꾸거나, 원하는 조건을 남겨주시면 찾아드릴게요.'}
         <br><button class="btn ghost sm" data-go="ask">조건 남기기</button></div>`;
    renderPager(pages);
    // 인기 매물 줄 (조회수 많은 순서, 숫자는 표시 안 함)
    const pop = state.popular.map((id) => state.items.find((l) => l.id === id)).filter(Boolean);
    $('popSec').hidden = !pop.length;
    $('popRow').innerHTML = pop.map((l, i) => card(l, i + 1)).join('');
    $('popDots').innerHTML = pop.length > 1 ? pop.map((_, i) => `<button type="button" data-dot="${i}"${i === 0 ? ' class="on"' : ''} tabindex="-1"></button>`).join('') : '';
    $('popRow').scrollLeft = 0;
    // 적용된 조건 표시
    const tags = [];
    if (state.botIds) tags.push('상담봇 추천 매물');
    if (state.region) tags.push(state.region);
    if (state.ptype) tags.push(state.ptype);
    if (state.price !== '' && ranges()[Number(state.price)]) tags.push(ranges()[Number(state.price)][0]);
    if (state.kw) tags.push(`"${state.kw}"`);
    $('filterInfo').hidden = !tags.length;
    $('filterInfo').innerHTML = tags.length ? `적용된 조건: ${tags.map(esc).join(' · ')} <button type="button" id="resetBtn">조건 초기화</button>` : '';
    document.querySelectorAll('#dealChips .chip').forEach((b) => b.classList.toggle('on', b.dataset.deal === state.deal));
    renderFavCount();
  }

  // ---------- 페이지 번호 ----------
  function renderPager(pages) {
    const el = $('pager');
    if (pages <= 1) { el.hidden = true; el.innerHTML = ''; return; }
    const cur = state.page;
    let from = Math.max(1, cur - 2), to = Math.min(pages, from + 4);
    from = Math.max(1, to - 4);
    const btn = (n, label, dis, aria) => `<button type="button" data-page="${n}"${dis ? ' disabled' : ''}${n === cur && !label ? ' class="on" aria-current="page"' : ''} aria-label="${aria || n + '페이지'}">${label || n}</button>`;
    let h = btn(cur - 1, icon('left'), cur === 1, '이전 페이지');
    if (from > 1) h += btn(1) + (from > 2 ? '<span>…</span>' : '');
    for (let i = from; i <= to; i++) h += btn(i);
    if (to < pages) h += (to < pages - 1 ? '<span>…</span>' : '') + btn(pages);
    h += btn(cur + 1, icon('right'), cur === pages, '다음 페이지');
    el.innerHTML = h; el.hidden = false;
  }

  // ---------- 전체 매물 화면 (상담봇은 작은 버튼으로, 매물은 넓게) ----------
  function setAllMode(on) {
    state.allMode = on;
    document.body.classList.toggle('mode-all', on);
    if (on) closeChat();
    else if (!isMobileChat() && !log.children.length) botStart();
  }

  function fillSelects() {
    const regions = [...new Set(state.items.map((l) => `${l.sido || ''} ${l.gu || ''}`.trim()).filter(Boolean))].sort();
    // 항목 글자 앞에 한 칸 띄움(&nbsp;). 검색 값(value)에는 공백이 안 들어감
    $('fRegion').innerHTML = '<option value="">&nbsp;지역 전체</option>' + regions.map((r) => `<option value="${esc(r)}">&nbsp;${esc(r)}</option>`).join('');
    $('fType').innerHTML = '<option value="">&nbsp;매물 종류 전체</option>' + TYPES.map((t) => `<option value="${t}">&nbsp;${t}</option>`).join('');
    priceMode = null; syncPriceOptions();
    $('dealChips').innerHTML = ['', ...DEALS].map((d) => `<button type="button" class="chip" data-deal="${d}">${d || '전체'}</button>`).join('');
  }

  // 가격대 목록: 거래 유형(월세·단기 ↔ 그 외)이 바뀌면 목록을 바꾸고 고른 가격대는 초기화
  let priceMode = null;
  function syncPriceOptions() {
    const mode = rentMode() ? 'rent' : 'price';
    if (mode === priceMode) return;
    if (priceMode !== null) state.price = '';
    priceMode = mode;
    const sel = $('fPrice');
    const rent = mode === 'rent';
    sel.innerHTML = `<option value="">&nbsp;${rent ? `${state.deal} 금액 전체` : '가격대 전체'}</option>`
      + ranges().map((r, i) => `<option value="${i}">&nbsp;${r[0]}</option>`).join('');
    sel.title = rent ? `${state.deal} 금액 기준 (관리비 제외)` : '보증금·매매가 기준';
    sel.value = state.price;
  }

  function scrollToList() { $('listSec').scrollIntoView({ behavior: 'smooth', block: 'start' }); }

  // ---------- 조회수 ----------
  // 같은 기기에서 VIEW_REPEAT_MINUTES 안에 다시 열면 세지 않음 (새로고침으로 부풀리기 방지)
  const VKEY = 'howgee_viewed';
  function countView(l) {
    const gap = Number(C.VIEW_REPEAT_MINUTES ?? 30) * 60000;
    let seen = {};
    try { seen = JSON.parse(localStorage.getItem(VKEY) || '{}') || {}; } catch { /* 저장 불가 브라우저 */ }
    const now = Date.now();
    if (gap > 0 && seen[l.id] && now - seen[l.id] < gap) return;
    seen[l.id] = now;
    for (const k of Object.keys(seen)) if (now - seen[k] > 86400000) delete seen[k]; // 하루 지난 기록 정리
    try { localStorage.setItem(VKEY, JSON.stringify(seen)); } catch { /* 무시 */ }
    fetch(`/api/listings/${encodeURIComponent(l.id)}/view`, { method: 'POST', keepalive: true }).catch(() => {});
  }

  // ---------- 상세 ----------
  function openDetail(id, push = true) {
    const l = state.items.find((x) => x.id === id);
    if (!l) { toast('거래가 끝났거나 내려간 매물이에요'); return; }
    if (push !== 'refresh') countView(l);
    state.openId = id;
    const photos = l.photos || [];
    const slides = photos.length
      ? photos.map((p, i) => `<div class="slide protect"><img class="bg" src="${photo(p, 'f')}" alt="" aria-hidden="true" ${i ? 'loading="lazy"' : ''} decoding="async"><img class="fg" src="${photo(p, 'f')}" alt="매물 사진 ${i + 1}" ${i ? 'loading="lazy"' : ''} decoding="async"></div>`).join('')
      : `<div class="slide" style="display:grid;place-items:center;color:#9aa59b">${icon('img')} 사진 준비 중</div>`;
    const spec = [
      ['전용면적', l.area ? `${l.area}㎡ (${(l.area / 3.3058).toFixed(1)}평)` : ''],
      ['공급면적', l.supply_area ? `${l.supply_area}㎡` : ''],
      ['방 / 욕실', l.rooms != null || l.baths != null ? `${l.rooms ?? '-'}개 / ${l.baths ?? '-'}개` : ''],
      ['해당층 / 총층', l.floor || l.total_floors ? `${l.floor || '-'} / ${l.total_floors ? l.total_floors + '층' : '-'}` : ''],
      ['관리비', l.maint != null ? (l.maint ? `${won(l.maint)}원` : '없음') : ''],
      ['주차', l.parking], ['입주가능일', l.move_in], ['방향', l.direction],
      ['사용승인일', l.approval_date], ['반려동물', l.pet],
    ].filter(([, v]) => v !== '' && v != null);
    const tags = (l.tags || '').split(/[,#]/).map((t) => t.trim()).filter(Boolean);
    $('detailSheet').innerHTML = `
      <button class="sheet-close" data-close aria-label="닫기">${icon('close')}</button>
      <div class="slider"><div class="slides" id="slides">${slides}</div>
        ${photos.length > 1 ? `<button class="slide-nav prev" data-slide="-1" aria-label="이전 사진">${icon('left')}</button><button class="slide-nav next" data-slide="1" aria-label="다음 사진">${icon('right')}</button>` : ''}
        ${photos.length ? `<span class="slide-count" id="slideCount">1 / ${photos.length}</span>` : ''}</div>
      <div class="detail">
        <div class="tags">${dealsOf(l).map((d) => `<span class="tag">${esc(d.deal)}</span>`).join('')}<span class="tag">${esc(l.ptype)}</span>${l.status === '계약진행중' ? '<span class="tag" style="background:#fdf1dc;color:#9a6512">계약진행중</span>' : ''}</div>
        <h3>${esc(l.title)}</h3>
        <div class="loc">${icon('pin')} ${esc(locText(l))} <span style="margin-left:6px;color:#8a928b">· ${regDate(l.created_at, true)} 등록</span></div>
        <div class="bigprice">${esc(priceText(l))}</div>
        ${dealsOf(l).length > 1 ? `<div class="altprice">${dealsOf(l).slice(1).map((d) => `<div>${esc(priceText(d))}<span>도 가능</span></div>`).join('')}</div>` : ''}
        ${spec.length ? `<dl class="specs">${spec.map(([k, v]) => `<div><dt>${k}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>` : ''}
        ${tags.length ? `<div class="tags" style="margin-bottom:14px">${tags.map((t) => `<span class="tag gray">#${esc(t)}</span>`).join('')}</div>` : ''}
        ${l.description ? `<div class="desc">${esc(l.description)}</div>` : ''}
        <div class="actions">
          <button class="btn primary wide" data-ask="${esc(l.id)}">${icon('chat')} 이 매물 문의 남기기</button>
          <button class="btn ghost" data-share-ask="${esc(l.id)}">${icon('send')} 카톡·인스타로 문의</button>
          <a class="btn ghost" href="tel:${esc((C.PHONE || '').replace(/[^0-9+]/g, ''))}">${icon('phone')} 전화 문의</a>
          <button class="btn ghost" data-share="${esc(l.id)}">${icon('link')} 링크 복사</button>
          <button class="btn ghost" data-fav="${esc(l.id)}">${icon(fav.has(l.id) ? 'heart-f' : 'heart')} ${fav.has(l.id) ? '찜 해제' : '찜하기'}</button>
        </div>
        <p style="font-size:12px;color:#8a928b;margin:14px 0 0">매물번호 ${esc(l.id)} · 실제 정보는 상담 시 다시 확인해 드려요.</p>
      </div>`;
    openModal('detailModal');
    const sl = $('slides');
    if (sl && photos.length) sl.addEventListener('scroll', () => {
      const i = Math.round(sl.scrollLeft / sl.clientWidth) + 1;
      const c = $('slideCount'); if (c) c.textContent = `${i} / ${photos.length}`;
    }, { passive: true });
    if (push === true) history.replaceState(null, '', `?id=${encodeURIComponent(id)}`);
  }

  // 목록 위 표시줄: 상담봇 조건이 저장돼 있으면 "문의할 때 자동으로 같이 들어가요" 안내
  function renderCondBar() {
    const s = botSaved.get();
    const bar = $('condBar');
    bar.hidden = !s;
    if (s) bar.innerHTML = `<span class="cb-ico">${icon('bot', 'i')}</span><div><b>✔ 상담봇 조건 저장됨</b><span class="cb-val">${esc(condShort(s))}</span><small>매물을 카톡·인스타·문의로 보낼 때 이 조건이 자동으로 같이 들어가요</small></div><button type="button" class="btn ghost sm" data-cond-clear>지우기</button>`;
  }

  // ---------- 모달 ----------
  // 카톡·인스타로 보내기 (휴대폰·PC 똑같이): 내용을 먼저 복사 → 안내 창에서 [카톡 오픈채팅]/[인스타그램]을 누르고 붙여넣기
  // 안내 창에 복사된 내용을 보여주고, 복사가 안 되는 브라우저면 [다시 복사하기]·직접 길게 눌러 복사할 수 있게 함
  // 보낼 내용 고르기: 매물마다 체크(기본 전부), 상담봇 조건 체크(있으면 자동으로 켜짐). 체크를 바꾸면 바로 다시 복사
  let shareNow = '';
  let shareCtx = { kind: 'one', list: [], conds: null };
  const condShort = (c) => c.short || c.text.replace(/\n/g, ' · ');
  function shareSelected() {
    const ids = [...$('sharePick').querySelectorAll('input[data-pick-id]:checked')].map((x) => x.dataset.pickId);
    const list = shareCtx.list.filter((l) => ids.includes(l.id));
    const withCond = shareCtx.conds && $('pickCond') && $('pickCond').checked;
    return { list, conds: withCond ? shareCtx.conds : null };
  }
  async function refreshShare(again) {
    const { list, conds } = shareSelected();
    const empty = !list.length && !conds;
    shareNow = empty ? '' : shareBody(shareCtx.kind, list, conds);
    $('shareText').value = shareNow;
    const st = $('shareState');
    if (empty) { st.textContent = '보낼 내용을 하나 이상 골라주세요'; st.classList.add('fail'); return; }
    const ok = await copy(shareNow, false);
    st.textContent = ok ? (again ? '✔ 바꾼 내용으로 다시 복사됐어요' : '✔ 아래 내용이 복사됐어요') : '자동 복사가 안 됐어요. [다시 복사하기]를 누르거나 아래 글을 길게 눌러 복사해 주세요';
    st.classList.toggle('fail', !ok);
  }
  function openShare(kind, list, title) {
    const conds = botSaved.get();
    shareCtx = { kind, list: list.slice(0, 20), conds };
    $('shareTitle').textContent = title;
    const items = shareCtx.list.map((l) => `<label class="pick"><input type="checkbox" data-pick-id="${esc(l.id)}" checked><span><b>${esc(l.title)}</b><small>${esc(allPriceText(l))}</small></span></label>`).join('');
    $('sharePick').innerHTML = (shareCtx.list.length ? `<p class="pick-h">보낼 매물 <small>${shareCtx.list.length > 1 ? '빼고 싶은 매물은 체크를 풀어주세요' : ''}</small></p>${items}` : '')
      + (conds ? `<p class="pick-h">내가 고른 조건</p><label class="pick cond"><input type="checkbox" id="pickCond" checked><span><b>상담봇에서 고른 조건 <em>자동으로 넣었어요</em></b><small>${esc(condShort(conds))}</small></span></label>` : '');
    const touch = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
    $('shareNative').hidden = !(navigator.share && touch); // 휴대폰만: 카톡 친구·문자 등 다른 앱으로도 보낼 수 있게
    openModal('shareModal');
    const sheet = $('shareModal').querySelector('.sheet'); if (sheet) sheet.scrollTop = 0;
    return refreshShare(false);
  }
  const shareAsk = (list) => openShare(list.length > 1 ? 'fav' : 'one', list, list.length > 1 ? `관심매물 ${list.length}개 문의 보내기` : '이 매물 문의 보내기');
  function openModal(id) { $(id).classList.add('open'); document.body.style.overflow = 'hidden'; }
  function closeModal(id) {
    $(id).classList.remove('open');
    if (!document.querySelector('.modal.open') && !$('chatPanel').classList.contains('open')) document.body.style.overflow = '';
    if (id === 'detailModal') { state.openId = null; history.replaceState(null, '', location.pathname); }
  }

  // ---------- 문의 ----------
  let turnstileId = null;
  let askFavIds = []; // 관심매물 전체 문의일 때 매물번호 목록
  function openAsk(prefill = {}) {
    const f = $('askForm');
    $('askDone').hidden = true; $('askErr').textContent = '';
    f.reset();
    const l = prefill.listingId ? state.items.find((x) => x.id === prefill.listingId) : null;
    f.listingId.value = l ? l.id : '';
    const favs = (prefill.favIds || []).map((id) => state.items.find((x) => x.id === id)).filter(Boolean).slice(0, 20);
    askFavIds = favs.map((x) => x.id);
    $('askAbout').textContent = favs.length
      ? `관심매물 ${favs.length}개 문의\n${favs.map((x) => `· ${x.title} (${allPriceText(x)})`).join('\n')}`
      : l ? `문의 매물: ${l.title} (${allPriceText(l)})` : '조건을 남겨주시면 확인 후 연락드릴게요.';
    for (const k of ['region', 'budget', 'moveIn', 'message']) if (prefill[k]) f[k].value = prefill[k];
    // 상담봇에서 고른 조건이 있으면 빈 칸에 자동으로 채우고, 채웠다고 알려줌 (손님이 고치거나 지울 수 있음)
    const saved = botSaved.get();
    let filled = !!prefill.fromBot;
    if (saved) {
      if (!f.region.value && saved.region) { f.region.value = saved.region; filled = true; }
      if (!f.budget.value && saved.budget) { f.budget.value = saved.budget; filled = true; }
      if (!f.moveIn.value && saved.moveIn) { f.moveIn.value = saved.moveIn; filled = true; }
      if (!f.message.value) { f.message.value = `[상담봇에서 고른 조건]\n${saved.text}`; filled = true; }
    }
    $('askAuto').hidden = !filled;
    // 운영자가 사이트 문의 창을 꺼둔 경우: 안내 + 보내기 버튼 막기
    const closed = state.inquiryOpen === false;
    $('askClosed').hidden = !closed;
    $('askSubmit').disabled = closed;
    openModal('askModal');
    if (C.TURNSTILE_SITE_KEY) loadTurnstile();
  }
  function loadTurnstile() {
    const render = () => {
      if (turnstileId !== null) { window.turnstile.reset(turnstileId); return; }
      turnstileId = window.turnstile.render('#turnstileBox', { sitekey: C.TURNSTILE_SITE_KEY, language: 'ko' });
    };
    if (window.turnstile) return render();
    if (loadTurnstile.loading) return;
    loadTurnstile.loading = true;
    window.onTurnstileLoad = render;
    const s = document.createElement('script');
    s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit&onload=onTurnstileLoad';
    s.async = true;
    document.head.appendChild(s);
  }
  $('askForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    const err = $('askErr');
    err.textContent = '';
    const phone = f.phone.value.replace(/[^0-9]/g, '');
    if (!/^0\d{8,10}$/.test(phone)) { err.textContent = '연락처를 정확히 입력해 주세요. (예: 010-1234-5678)'; f.phone.focus(); return; }
    if (!f.consent.checked) { err.textContent = '개인정보 수집·이용에 동의해 주세요.'; return; }
    if (!f.age14.checked) { err.textContent = '만 14세 이상만 문의를 남길 수 있어요. 만 14세 미만은 보호자가 대신 문의해 주세요.'; return; }
    const body = {
      listingId: f.listingId.value || null, listingIds: askFavIds.length ? askFavIds : undefined, name: f.name.value, phone, region: f.region.value, budget: f.budget.value,
      moveIn: f.moveIn.value, message: f.message.value, consent: true, age14: true, website: f.website.value,
      turnstileToken: C.TURNSTILE_SITE_KEY && window.turnstile && turnstileId !== null ? window.turnstile.getResponse(turnstileId) : '',
    };
    const btn = $('askSubmit');
    btn.disabled = true; btn.textContent = '보내는 중…';
    try {
      const r = await fetch('/api/inquiries', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const d = await r.json().catch(() => ({}));
      if (!r.ok || !d.ok) throw new Error(d.error || '접수하지 못했어요. 전화나 카톡으로 연락 주세요.');
      $('askDone').hidden = false; $('askOk').focus();
    } catch (ex) {
      err.textContent = ex.message || '접수하지 못했어요. 전화나 카톡으로 연락 주세요.';
      if (turnstileId !== null && window.turnstile) window.turnstile.reset(turnstileId);
    } finally {
      btn.disabled = false; btn.textContent = '문의 보내기';
    }
  });

  // ---------- 상담봇 (정해진 질문·답변 방식, 유료 AI 아님) ----------
  // 질문 순서: ① 입주 시기 ② 구조 ③ 예산(거래 유형 → 금액) ④ 지역 ⑤ 필요 조건(건너뛰기 가능)
  // 조건에 모두 맞는 매물이 있으면 보여주고, 없으면 가장 비슷한 매물을 추천합니다.
  const bot = { step: null, data: {} };
  const log = $('chatLog');
  const STEPS = 5;
  function say(text, who = 'bot') {
    const d = document.createElement('div');
    d.className = `msg ${who}`;
    d.textContent = text;
    log.appendChild(d);
    log.scrollTop = log.scrollHeight;
  }
  // 버튼 묶음. 하나를 누르면 묶음이 사라짐 (링크 버튼은 남김)
  function options(list, cls = '') {
    const d = document.createElement('div');
    d.className = `opts ${cls}`.trim();
    for (const o of list) {
      const el = document.createElement(o.href ? 'a' : 'button');
      if (!o.href) el.type = 'button';
      el.textContent = o.label;
      if (o.href) { el.href = o.href; el.target = '_blank'; el.rel = 'noopener'; }
      el.addEventListener('click', () => { if (!o.href && !o.keep) d.remove(); o.run && o.run(); });
      d.appendChild(el);
    }
    log.appendChild(d);
    log.scrollTop = log.scrollHeight;
    return d;
  }
  const clearOpts = () => log.querySelectorAll('.opts:not(.keep)').forEach((o) => o.remove());
  const q = (n, text) => say(`(${n}/${STEPS}) ${text}`);

  // 예산 구간 (만원). 월세·단기는 "월세" 기준, 전세·매매는 금액 기준
  // 월세·단기: [보증금 최대, 월세 최대] (만원) → 버튼에 "1,000 / 30만 이하"처럼 보증금과 월세를 같이 표시
  // 바꾸려면 숫자만 고치면 됨. 매물의 보증금과 월세가 둘 다 이 금액 이하이면 맞는 매물
  const MONTHLY_PAIRS = {
    월세: [[1000, 50], [2000, 80], [3000, 100]],
    단기: [[0, 50], [100, 50], [300, 80], [500, 100]],
  };
  const pairLabel = (dep, rent) => `${dep > 0 ? dep.toLocaleString() : '무보증'} / ${rent}만 이하`;
  const pairBudget = (dep, rent) => ({ label: `보증금 ${dep > 0 ? `${dep.toLocaleString()}만` : '없음(무보증)'} · 월 ${rent}만 이하`, lo: 0, hi: rent, depMax: dep });
  const BUDGETS = {
    전세: [['1억 이하', 0, 10000], ['1억~2억', 10000, 20000], ['2억~3억', 20000, 30000], ['3억~5억', 30000, 50000], ['5억 이상', 50000, Infinity]],
    매매: [['3억 이하', 0, 30000], ['3억~5억', 30000, 50000], ['5억~10억', 50000, 100000], ['10억 이상', 100000, Infinity]],
  };
  // 필요 조건 → 매물에서 확인하는 방법
  const text = (l) => [l.title, l.tags, l.description].join(' ');
  const CONDS = {
    주차: (l) => (l.parking && !/불가|없음|안\s*됨|x/i.test(l.parking)) || (/주차/.test(text(l)) && !/주차\s*(불가|없음|안)/.test(text(l))),
    반려동물: (l) => l.pet === '가능' || l.pet === '협의' || (!l.pet && /반려|펫|애완/.test(text(l))),
    신축: (l) => /신축/.test(text(l)),
    풀옵션: (l) => /풀\s*옵션/.test(text(l)),
    엘리베이터: (l) => /엘리베이터|엘베/.test(text(l)),
    역세권: (l) => /역세권|역\s*도보|역\s*\d+\s*분|역\s*앞/.test(text(l)),
  };
  const isMonthly = (deal) => deal === '월세' || deal === '단기';
  // "2억 5천", "1억5000", "5000", "60만", "1,000" → 만원 숫자
  function parseMan(t) {
    const s = String(t).replace(/[,\s원]/g, '');
    const m = s.match(/^(?:(\d+(?:\.\d+)?)억)?(?:(\d+(?:\.\d+)?)천)?(?:(\d+(?:\.\d+)?)만?)?$/);
    if (!m || !(m[1] || m[2] || m[3])) return null;
    return Number(m[1] || 0) * 10000 + Number(m[2] || 0) * 1000 + Number(m[3] || 0);
  }

  function botStart() {
    bot.step = null; bot.data = { conds: [] };
    say('안녕하세요! 하우지 상담봇이에요 😊\n5가지만 여쭤보고 맞는 매물을 찾아드릴게요.\n버튼을 누르거나 직접 입력하셔도 돼요.');
    askMoveIn();
  }
  // ① 입주 시기
  function askMoveIn() {
    bot.step = 'moveIn';
    q(1, '언제 입주할 예정이세요?');
    options(['즉시', '1개월 이내', '2~3개월 이내', '3개월 이후', '협의 가능'].map((t) => ({ label: t, run: () => { say(t, 'me'); bot.data.moveIn = t; askType(); } })));
  }
  // ② 구조
  function askType() {
    bot.step = 'type';
    q(2, '어떤 구조를 원하세요?');
    options([...TYPES, '상관없음'].map((t) => ({ label: t, run: () => { say(t, 'me'); bot.data.ptype = t === '상관없음' ? '' : t; askDeal(); } })));
  }
  // ③ 예산: 거래 유형 → 금액
  function askDeal() {
    bot.step = 'deal';
    q(3, '예산을 여쭤볼게요. 어떤 거래를 원하세요?');
    options([...DEALS, '상관없음'].map((d) => ({ label: d, run: () => { say(d, 'me'); bot.data.deal = d === '상관없음' ? '' : d; if (d === '상관없음') { bot.data.budget = null; askRegion(); } else askBudget(); } })));
  }
  function askBudget() {
    bot.step = 'budget';
    const deal = bot.data.deal;
    say(isMonthly(deal)
      ? `${deal} 예산을 골라주세요. 버튼은 "보증금 / 월세"예요. (만원)\n직접 입력도 돼요. (예: "1000/60" = 보증금 1000 · 월 60 이하, "60" = 월 60만 이하)`
      : `${deal} 예산을 골라주세요. 직접 입력도 돼요. (예: "2억", "1억 5천")`);
    const list = isMonthly(deal)
      ? MONTHLY_PAIRS[deal].map(([dep, rent]) => ({ label: pairLabel(dep, rent), budget: pairBudget(dep, rent) }))
      : BUDGETS[deal].map(([label, lo, hi]) => ({ label, budget: { label, lo, hi, depMax: null } }));
    options([...list.map((o) => ({ label: o.label, run: () => { say(o.budget.label, 'me'); bot.data.budget = o.budget; askRegion(); } })),
      { label: '상관없음', run: () => { say('상관없음', 'me'); bot.data.budget = null; askRegion(); } }]);
  }
  // 직접 입력한 예산 해석
  function typedBudget(t) {
    const deal = bot.data.deal;
    const parts = t.split(/[\/~,]|보증금|월세?|월/).map((x) => parseMan(x)).filter((x) => x != null);
    if (!parts.length) return null;
    if (isMonthly(deal)) {
      const [a, b] = parts;
      return b != null ? { label: `보증금 ${won(a)} 이하 · 월 ${won(b)} 이하`, lo: 0, hi: b, depMax: a }
        : { label: `월 ${won(a)} 이하`, lo: 0, hi: a, depMax: null };
    }
    return { label: `${won(parts[0])} 이하`, lo: 0, hi: parts[0], depMax: null };
  }
  // ④ 지역
  function askRegion() {
    bot.step = 'region';
    q(4, '원하는 지역을 골라주시거나 입력해 주세요. (예: 전포동, 해운대구)');
    // 지역 버튼: 매물이 있는 지역을 매물 많은 순으로 전부 표시. 12개가 넘으면 구 단위로 묶어서 표시
    const countBy = (key) => {
      const m = new Map();
      state.items.forEach((l) => { const k = key(l); if (k) m.set(k, (m.get(k) || 0) + 1); });
      return [...m.entries()].sort((a, b) => b[1] - a[1]).map(([k]) => k);
    };
    let areas = countBy((l) => [l.gu, l.dong].filter(Boolean).join(' '));
    if (areas.length > 12) areas = countBy((l) => l.gu || l.sido || '');
    options([...areas, '상관없음'].map((r) => ({ label: r, run: () => { say(r, 'me'); bot.data.region = r === '상관없음' ? '' : r; askConds(); } })));
  }
  // ⑤ 필요 조건 (여러 개 선택, 건너뛰기 가능)
  function askConds() {
    bot.step = 'conds';
    bot.data.conds = [];
    q(5, '꼭 필요한 조건이 있으면 골라주세요. (여러 개 가능 · 없으면 건너뛰기)');
    const box = options(Object.keys(CONDS).map((c) => ({ label: c, keep: true, run: null })), 'multi');
    box.querySelectorAll('button').forEach((b) => b.addEventListener('click', () => {
      b.classList.toggle('on');
      bot.data.conds = [...box.querySelectorAll('button.on')].map((x) => x.textContent);
    }));
    options([
      { label: '선택 완료', run: () => { box.remove(); say(bot.data.conds.length ? bot.data.conds.join(', ') : '없음', 'me'); finish(); } },
      { label: '건너뛰기', run: () => { box.remove(); bot.data.conds = []; say('건너뛰기', 'me'); finish(); } },
    ]);
  }

  // 매물 1개가 조건 각각에 맞는지
  function check(l) {
    const d = bot.data;
    const deals = dealsOf(l).filter((x) => !d.deal || x.deal === d.deal);
    const inBudget = (x) => {
      const b = d.budget;
      if (!b) return true;
      const v = isMonthly(x.deal) ? Number(x.rent || 0) : Number(x.price || 0);
      // "월 40만 이하"처럼 경계 금액도 포함 (딱 40만인 매물도 나옴)
      return v >= b.lo && v <= b.hi && (b.depMax == null || Number(x.price || 0) <= b.depMax);
    };
    const where = [l.sido, l.gu, l.dong].join(' ').replace(/\s+/g, '');
    const missing = (d.conds || []).filter((c) => !CONDS[c](l));
    return {
      type: !d.ptype || l.ptype === d.ptype,
      deal: deals.length > 0,
      budget: deals.some(inBudget),
      region: !d.region || d.region.split(/\s+/).every((w) => where.includes(w.replace(/(특별시|광역시)$/, ''))),
      missing,
      deal1: deals.find(inBudget) || deals[0] || dealsOf(l)[0],
    };
  }
  const summary = () => {
    const d = bot.data;
    return ['[하우지 상담 요청]', d.moveIn && `입주: ${d.moveIn}`, d.ptype && `구조: ${d.ptype}`,
      d.deal && `거래: ${d.deal}`, d.budget && `예산: ${d.budget.label}`, d.region && `지역: ${d.region}`,
      d.conds && d.conds.length && `필요 조건: ${d.conds.join(', ')}`].filter(Boolean).join('\n');
  };
  const listLabel = (l, x) => `${locShort(l)} ${l.ptype} · ${priceText(x || dealsOf(l)[0])}`;
  // 결과 매물 버튼 (누르면 상세가 열림)
  function showListings(arr) {
    options(arr.map(({ l, c }) => ({ label: listLabel(l, c.deal1), keep: true, run: () => openDetail(l.id) })), 'keep list');
  }
  function finish() {
    bot.step = null;
    bot.shownIds = [];
    const d = bot.data;
    const condText = summary().split('\n').slice(1).join('\n');
    // 조건 저장 → 매물을 카톡·인스타·문의로 보낼 때 자동으로 같이 들어감 (목록 위 표시줄에도 보임)
    botSaved.set(condText ? { text: condText, short: [d.moveIn, d.ptype, d.deal, d.budget && d.budget.label, d.region, ...(d.conds || [])].filter(Boolean).join(' · '), region: d.region || '', budget: d.budget ? d.budget.label : '', moveIn: d.moveIn || '' } : null);
    renderCondBar();
    say(`정리해 드릴게요.\n${condText || '조건 없음'}`);
    if (condText) say('✔ 이 조건을 저장했어요.\n관심매물이나 매물을 카톡·인스타·문의로 보낼 때 자동으로 같이 들어가요.');
    if (!state.items.length) {
      say('지금 올라와 있는 매물이 없어요. 조건을 남겨주시면 맞는 매물을 찾아서 연락드릴게요.');
      return afterResult();
    }
    const all = state.items.map((l) => ({ l, c: check(l) }));
    const ok = all.filter(({ c }) => c.type && c.deal && c.budget && c.region && !c.missing.length);
    if (ok.length) {
      say(`조건에 맞는 매물이 ${ok.length}개 있어요! 눌러서 자세히 보세요.`);
      showListings(ok.slice(0, 5));
      bot.shownIds = ok.slice(0, 5).map(({ l }) => l.id);
      if (ok.length > 5) say(`나머지 ${ok.length - 5}개는 "목록에서 모두 보기"로 확인하세요.`);
      bot.lastIds = ok.map(({ l }) => l.id);
      return afterResult(true);
    }
    // 딱 맞는 게 없으면: 맞는 조건이 많은 순서로 추천 (구조·거래 3점, 예산·지역 2점, 필요 조건 1개당 1점)
    const scored = all.map(({ l, c }) => ({ l, c, s: (c.type ? 3 : 0) + (c.deal ? 3 : 0) + (c.budget && c.deal ? 2 : 0) + (c.region ? 2 : 0) + ((d.conds || []).length - c.missing.length) }))
      .filter((x) => x.s > 0)
      .sort((a, b) => b.s - a.s || (a.l.created_at < b.l.created_at ? 1 : -1))
      .slice(0, 3);
    if (!scored.length) {
      say('조건에 맞거나 비슷한 매물이 지금은 없어요. 조건을 남겨주시면 새로 나오는 매물 중에서 찾아 연락드릴게요.');
      return afterResult();
    }
    const diff = (c) => [!c.type && '구조', !c.deal && '거래 유형', c.deal && !c.budget && '예산', !c.region && '지역', ...c.missing.map((m) => `${m} 미확인`)].filter(Boolean).join(', ');
    say(`조건에 딱 맞는 매물은 지금 없어요. 대신 가장 비슷한 매물을 추천해 드릴게요.\n${scored.map(({ l, c }) => `· ${locShort(l)} ${l.ptype} — 다른 점: ${diff(c)}`).join('\n')}`);
    showListings(scored);
    bot.lastIds = scored.map(({ l }) => l.id);
    bot.shownIds = bot.lastIds;
    afterResult(true);
  }
  function afterResult(hasList) {
    const d = bot.data;
    const opts = [];
    if (hasList) opts.push({ label: '목록에서 모두 보기', keep: true, run: () => { Object.assign(state, { favOnly: false, deal: '', region: '', ptype: '', price: '', kw: '', botIds: bot.lastIds }); syncForm(); render(); if (isMobileChat()) closeChat(); scrollToList(); } });
    opts.push({ label: '이 조건으로 문의 남기기', keep: true, run: () => openAsk({ region: d.region, budget: d.budget && d.budget.label, moveIn: d.moveIn, message: summary(), fromBot: true }) });
    // 카톡: 조건 + 상담봇이 보여준 매물(체크해서 고르기)
    opts.push({ label: '카톡으로 상담하기', keep: true, run: () => openShare('bot', (bot.shownIds || []).map((id) => state.items.find((l) => l.id === id)).filter(Boolean), '상담 내용 보내기') });
    opts.push({ label: '처음부터 다시', run: () => resetChat() });
    options(opts, 'keep');
  }
  function contact() {
    say(`편한 방법으로 연락 주세요.\n전화: ${C.PHONE || '-'}`);
    options([
      { label: '카톡 오픈채팅', href: C.KAKAO_OPENCHAT },
      { label: '전화하기', href: `tel:${(C.PHONE || '').replace(/[^0-9+]/g, '')}` },
      { label: '문의 남기기', keep: true, run: () => openAsk() },
      { label: '조건으로 매물 찾기', run: () => resetChat() },
    ], 'keep');
  }
  // 대화 초기화: 대화 내용과 상담봇 결과 목록을 지우고 처음부터
  function resetChat() {
    log.innerHTML = '';
    botSaved.set(null);
    renderCondBar();
    if (state.botIds) { state.botIds = null; render(); }
    botStart();
  }
  $('chatReset').addEventListener('click', resetChat);

  $('chatForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const t = $('chatText').value.trim();
    if (!t) return;
    $('chatText').value = '';
    say(t, 'me');
    const s = bot.step;
    if (s) clearOpts();
    if (s === 'moveIn') { bot.data.moveIn = t.slice(0, 30); return askType(); }
    if (s === 'type') {
      const hit = TYPES.find((x) => t.includes(x)) || (/상관|아무|무관/.test(t) ? '' : null);
      if (hit == null) { say(`${TYPES.join(', ')} 중에서 골라주세요.`); return askType(); }
      bot.data.ptype = hit; return askDeal();
    }
    if (s === 'deal') {
      const hit = DEALS.find((x) => t.includes(x)) || (/상관|아무|무관/.test(t) ? '' : null);
      if (hit == null) { say('월세, 전세, 매매, 단기 중에서 골라주세요.'); return askDeal(); }
      bot.data.deal = hit;
      return hit ? askBudget() : (bot.data.budget = null, askRegion());
    }
    if (s === 'budget') {
      if (/상관|아무|무관/.test(t)) { bot.data.budget = null; return askRegion(); }
      const b = typedBudget(t);
      if (!b) { say('금액을 이해하지 못했어요. 숫자로 입력해 주세요. (예: 60, 1000/60, 2억)'); return askBudget(); }
      bot.data.budget = b; say(`예산: ${b.label}로 찾아볼게요.`); return askRegion();
    }
    if (s === 'region') { bot.data.region = /상관|아무|무관/.test(t) ? '' : t.slice(0, 30); return askConds(); }
    if (s === 'conds') {
      bot.data.conds = Object.keys(CONDS).filter((c) => t.includes(c) || (c === '반려동물' && /강아지|고양이|펫|애완/.test(t)));
      return finish();
    }
    // 질문 중이 아닐 때: 키워드로 매물 찾기
    if (/상담|연락|전화|카톡|사람/.test(t)) return contact();
    Object.assign(state, { kw: t.slice(0, 40), favOnly: false, botIds: null }); syncForm(); render();
    const n = filtered().length;
    say(n ? `"${state.kw}"(으)로 매물 ${n}개를 찾았어요. 목록을 확인해 주세요.` : '해당 키워드의 매물이 없어요. 조건으로 찾아보시거나 상담으로 연결해 드릴게요.');
    options([{ label: '조건으로 매물 찾기', run: () => resetChat() }, { label: '상담원 연결', run: () => contact() }]);
  });
  const isMobileChat = () => window.matchMedia('(max-width: 1023px)').matches;
  function openChat() {
    $('chatPanel').classList.add('open');
    if (isMobileChat()) document.body.style.overflow = 'hidden';
    if (!log.children.length) botStart();
  }
  function closeChat() { $('chatPanel').classList.remove('open'); if (!document.querySelector('.modal.open')) document.body.style.overflow = ''; }

  // ---------- 바로가기 ----------
  function go(where) {
    $('drawer').classList.remove('open');
    if (where === 'all') { Object.assign(state, { favOnly: false, deal: '', region: '', ptype: '', price: '', kw: '', botIds: null }); syncForm(); setAllMode(true); render(); window.scrollTo({ top: 0, behavior: 'smooth' }); }
    if (where === 'home') { setAllMode(false); render(); window.scrollTo({ top: 0, behavior: 'smooth' }); }
    if (where === 'fav') { state.favOnly = true; render(); scrollToList(); }
    if (where === 'ask') openAsk();
    if (where === 'bot') openChat();
  }
  function syncForm() {
    $('fRegion').value = state.region; $('fType').value = state.ptype; $('fPrice').value = state.price; $('fKw').value = state.kw; $('fSort').value = state.sort;
  }

  // ---------- 이벤트 ----------
  document.addEventListener('click', (e) => {
    const t = e.target;
    const favBtn = t.closest('[data-fav]');
    if (favBtn) { e.stopPropagation(); toggleFav(favBtn.dataset.fav); return; }
    const pg = t.closest('[data-page]');
    if (pg && !pg.disabled) { state.page = Number(pg.dataset.page); render(); scrollToList(); return; }
    const goBtn = t.closest('[data-go]');
    if (goBtn) { go(goBtn.dataset.go); return; }
    const askBtn = t.closest('[data-ask]');
    if (askBtn) { openAsk({ listingId: askBtn.dataset.ask }); return; }
    const share = t.closest('[data-share]');
    if (share) { copy(`${location.origin}/?id=${encodeURIComponent(share.dataset.share)}`, '매물 링크를 복사했어요'); return; }
    // 카톡·인스타로 문의: 휴대폰은 공유 창(카톡·인스타 등 앱 고르기), PC는 복사 후 보낼 곳 고르기
    const shareAskBtn = t.closest('[data-share-ask]');
    if (shareAskBtn) {
      const l = state.items.find((x) => x.id === shareAskBtn.dataset.shareAsk);
      if (l) shareAsk([l]);
      return;
    }
    if (t.closest('[data-cond-clear]')) { botSaved.set(null); renderCondBar(); toast('상담봇 조건을 지웠어요'); return; }
    if (t.closest('[data-share-fav]')) {
      const list = state.items.filter((l) => fav.has(l.id));
      if (!list.length) return toast('담은 관심매물이 없어요');
      if (list.length > 20) toast('한 번에 20개까지 보내져요. 앞의 20개만 보낼게요');
      shareAsk(list.slice(0, 20));
      return;
    }
    const slideBtn = t.closest('[data-slide]');
    if (slideBtn) { const sl = $('slides'); sl.scrollBy({ left: sl.clientWidth * Number(slideBtn.dataset.slide), behavior: 'smooth' }); return; }
    if (t.closest('[data-close]')) { closeModal(t.closest('.modal').id); return; }
    if (t.classList.contains('modal')) { closeModal(t.id); return; }
    if (t.id === 'resetBtn') { go('all'); return; }
    if (t.closest('[data-reload]')) { location.reload(); return; }
    const chip = t.closest('#dealChips .chip');
    if (chip) { state.deal = chip.dataset.deal; state.botIds = null; render(); return; }
    const c = t.closest('.card');
    if (c) openDetail(c.dataset.id);
  });
  // 문의 접수 알림의 [확인] → 알림과 문의 창 모두 닫고 입력 내용 비움
  function askDoneOk() {
    $('askDone').hidden = true;
    $('askForm').reset();
    closeModal('askModal');
  }
  $('askOk').addEventListener('click', askDoneOk);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !$('askDone').hidden) { askDoneOk(); return; }
    if (e.key === 'Escape') {
      const open = document.querySelector('.modal.open');
      if (open) closeModal(open.id); else if ($('chatPanel').classList.contains('open')) closeChat(); else $('drawer').classList.remove('open');
    }
    if (e.key === 'Enter' && e.target.classList && e.target.classList.contains('card')) openDetail(e.target.dataset.id);
  });
  $('searchForm').addEventListener('submit', (e) => {
    e.preventDefault();
    Object.assign(state, { region: $('fRegion').value, ptype: $('fType').value, price: $('fPrice').value, kw: $('fKw').value.trim(), favOnly: false, botIds: null });
    render();
    scrollToList();
  });
  $('fSort').addEventListener('change', (e) => { state.sort = e.target.value; render(); });
  $('menuBtn').addEventListener('click', () => $('drawer').classList.add('open'));
  $('drawer').addEventListener('click', (e) => { if (e.target.id === 'drawer' || e.target.closest('[data-close-drawer]')) $('drawer').classList.remove('open'); });
  $('favTop').addEventListener('click', () => go('fav'));
  $('favAskBtn').addEventListener('click', () => {
    const ids = state.items.filter((l) => fav.has(l.id)).map((l) => l.id);
    if (!ids.length) return toast('담은 관심매물이 없어요');
    if (ids.length > 20) toast('한 번에 20개까지 문의돼요. 앞의 20개만 보낼게요');
    openAsk({ favIds: ids });
  });
  $('chatOpen').addEventListener('click', openChat);
  $('chatFab').addEventListener('click', openChat);
  // 인기 매물 (휴대폰): 한 장씩 넘기기 + 아래 점으로 몇 번째인지 표시
  $('popRow').addEventListener('scroll', () => {
    const row = $('popRow');
    const i = Math.round(row.scrollLeft / (row.clientWidth + 12));
    document.querySelectorAll('#popDots button').forEach((b, n) => b.classList.toggle('on', n === i));
  }, { passive: true });
  $('popDots').addEventListener('click', (e) => {
    const b = e.target.closest('[data-dot]');
    if (!b) return;
    const row = $('popRow');
    row.scrollTo({ left: Number(b.dataset.dot) * (row.clientWidth + 12), behavior: 'smooth' });
  });
  $('chatClose').addEventListener('click', closeChat);

  // ---------- 고정 정보 ----------
  function initStatic() {
    const tel = `tel:${(C.PHONE || '').replace(/[^0-9+]/g, '')}`;
    for (const id of ['quickKakao', 'drawerKakao']) $(id).href = C.KAKAO_OPENCHAT || '#';
    $('drawerPhone').href = tel;
    $('drawerInsta').href = C.INSTAGRAM || '#';
    $('shareKakao').href = C.KAKAO_OPENCHAT || '#';
    $('shareInsta').href = C.INSTAGRAM || '#';
    $('sharePick').addEventListener('change', () => refreshShare(true));
    // [카톡 오픈채팅]/[인스타그램]을 누르면 운영자 문의 목록에 "카톡"/"인스타"로 기록 (이름·연락처 없음, 실패해도 손님 화면엔 영향 없음)
    const logShare = (channel) => {
      const { list, conds } = shareSelected();
      if (!list.length && !conds) return;
      fetch('/api/inquiries/share', {
        method: 'POST', keepalive: true, headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channel, listingIds: list.map((l) => l.id), conds: conds ? { text: conds.text, region: conds.region, budget: conds.budget, moveIn: conds.moveIn } : null }),
      }).catch(() => {});
    };
    $('shareKakao').addEventListener('click', () => logShare('카톡'));
    $('shareInsta').addEventListener('click', () => logShare('인스타'));
    $('shareCopy').addEventListener('click', async () => {
      const ok = await copy(shareNow, '다시 복사했어요');
      if (!ok) { $('shareText').focus(); $('shareText').select(); }
    });
    $('shareNative').addEventListener('click', async () => {
      try { await navigator.share({ title: '하우지 문의', text: shareNow }); } catch { /* 공유 창을 닫음 */ }
    });
    $('retention').textContent = C.PRIVACY_RETENTION || '상담 완료 후 1년';
    const o = C.OFFICE || {};
    $('officeInfo').innerHTML = [
      ['중개사무소', o.name], ['소장', o.agent], ['등록번호', o.regNo], ['소재지', o.address], ['사무실 전화', o.officePhone],
    ].filter(([, v]) => v).map(([k, v]) => `<li>${k} ${esc(v)}</li>`).join('');
    $('ownerLine').textContent = C.OWNER_LINE || C.SITE_NAME || '하우지';
    $('footPhone').innerHTML = C.PHONE ? `휴대폰 <a href="${esc(tel)}">${esc(C.PHONE)}</a>` : '';
    $('pageNote').textContent = C.PAGE_NOTE || '';
    $('pageNote').hidden = !C.PAGE_NOTE;
    $('footLinks').innerHTML = `<a href="${esc(C.KAKAO_OPENCHAT || '#')}" target="_blank" rel="noopener">카톡 상담</a><a href="${esc(tel)}">전화 상담</a><a href="${esc(C.INSTAGRAM || '#')}" target="_blank" rel="noopener">인스타그램</a>`;
  }

  // 배경 사진 (config.js 의 HERO_IMAGE 에 파일 경로를 넣었을 때만)
  if (C.HERO_IMAGE) {
    const img = new Image();
    img.className = 'hero-img'; img.alt = ''; img.src = C.HERO_IMAGE;
    img.addEventListener('error', () => img.remove());
    document.querySelector('.hero').prepend(img);
  }

  // ---------- 시작 ----------
  // 매물 불러오기: 12초 안에 안 오면 끊고, 실패하면 2초 뒤 한 번 더 시도 (휴대폰 데이터가 잠깐 끊긴 경우 대비)
  async function getListings() {
    let last;
    for (let i = 0; i < 2; i++) {
      if (i) await new Promise((r) => setTimeout(r, 2000));
      const ctrl = window.AbortController ? new AbortController() : null;
      const timer = ctrl && setTimeout(() => ctrl.abort(), 12000);
      try {
        const r = await fetch('/api/listings', { headers: { Accept: 'application/json' }, signal: ctrl ? ctrl.signal : undefined });
        const d = await r.json();
        if (!r.ok || !d.ok) throw new Error(d.error || '');
        return d;
      } catch (e) { last = e; } finally { if (timer) clearTimeout(timer); }
    }
    throw last;
  }
  // 사진을 못 불러오면(구글 연결 문제 등) 깨진 그림 대신 "사진 준비 중" 표시
  document.addEventListener('error', (e) => {
    const img = e.target;
    if (!img || img.tagName !== 'IMG') return;
    const box = img.closest('.thumb, .slide');
    if (box && !box.classList.contains('img-err')) box.classList.add('img-err');
  }, true);

  async function load() {
    initStatic();
    fillSelects();
    renderFavCount();
    try {
      const d = await getListings();
      state.items = d.items || [];
      state.popular = d.popular || [];
      state.inquiryOpen = d.inquiryOpen !== false;
    } catch (e) {
      $('grid').innerHTML = `<div class="notice" style="grid-column:1/-1">매물을 불러오지 못했어요.<br>잠시 후 새로고침하시거나 전화·카톡으로 문의해 주세요.<br><button class="btn ghost sm" data-reload>새로고침</button></div>`;
      return;
    }
    // 실제 매물에 존재하는 지역만 지역 목록에 표시
    const keep = { deal: state.deal };
    fillSelects();
    state.deal = keep.deal;
    render();
    if (!isMobileChat() && !log.children.length) botStart(); // PC는 오른쪽 상담봇이 바로 보임
    const id = new URLSearchParams(location.search).get('id');
    if (id) openDetail(id, false);
  }
  load();
})();
