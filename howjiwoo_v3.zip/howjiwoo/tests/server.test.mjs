// 서버 자동 테스트 (Node.js 22 이상): node --no-warnings tests/server.test.mjs
// 가짜 데이터베이스·가짜 구글 드라이브로 보안 규칙과 기능을 검사합니다. 실제 서비스에는 영향 없음.
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { handle } from '../lib/router.js';
import { LISTING_ID_RE } from '../lib/http.js';
import { makeSession } from '../lib/access.js';

// ---- fake D1 ----
const db = new DatabaseSync(':memory:');
db.exec(readFileSync(new URL('../db/schema.sql', import.meta.url),'utf8'));
class Stmt { constructor(sql){this.sql=sql;this.args=[]} bind(...a){this.args=a;return this}
  first(){ return Promise.resolve(db.prepare(this.sql).get(...this.args) ?? null) }
  all(){ return Promise.resolve({results: db.prepare(this.sql).all(...this.args)}) }
  run(){ db.prepare(this.sql).run(...this.args); return Promise.resolve({success:true}) }
  _exec(){ const s=db.prepare(this.sql); return /^\s*select/i.test(this.sql)?{results:s.all(...this.args)}:(s.run(...this.args),{results:[]}) } }
const DB = { prepare:(s)=>new Stmt(s), batch: async (arr)=>{ db.exec('BEGIN'); try{const r=arr.map(s=>s._exec()); db.exec('COMMIT'); return r}catch(e){db.exec('ROLLBACK'); throw e} } };

// ---- 로그인 쿠키 setup (구글 로그인 방식) ----
const SECRET='test-session-secret-0123456789abcdef';
const baseEnv={ADMIN_MODE:'on', ADMIN_EMAILS:'boss@example.com', ADMIN_SESSION_SECRET:SECRET, GOOGLE_CLIENT_ID:'c',GOOGLE_CLIENT_SECRET:'s',GOOGLE_REFRESH_TOKEN:'r'};
const good = await makeSession(baseEnv,'Boss@Example.com');
const wrongEmail = await makeSession(baseEnv,'x@y.com');
const expired = await makeSession(baseEnv,'boss@example.com',-1);
const tampered = good.slice(0,-4)+'AAAA';
const otherSecret = await makeSession({...baseEnv,ADMIN_SESSION_SECRET:'another-secret-0123456789abcdefghij'},'boss@example.com');
const b64u = (b)=>Buffer.from(b).toString('base64url');
const now=Math.floor(Date.now()/1000);
const sim2={id:{iss:'https://accounts.google.com',aud:'c',email:'Boss@Example.com',email_verified:true,exp:now+3600}, tokenFail:false, lastTokenBody:null};
const idToken=(p)=>`${b64u(JSON.stringify({alg:'RS256'}))}.${b64u(JSON.stringify(p))}.sig`;

// ---- fake fetch (Google + Access certs + Turnstile) ----
const drive = new Map(); let fileSeq=0; const sim={driveDown:false, tokenBad:false}; const calls=[]; const pushes=[]; const pending=[];
async function fakeFetch(url, init={}){ url=String(url); calls.push([init.method||'GET', url.replace(/\?.*/,'')]);
  if(url.startsWith('https://oauth2.googleapis.com/token') && String(init.body).includes('authorization_code')){ sim2.lastTokenBody=new URLSearchParams(String(init.body));
    return sim2.tokenFail? Response.json({error:'invalid_grant'},{status:400}) : Response.json({access_token:'AT',id_token:idToken(sim2.id)}) }
  if(url.startsWith('https://oauth2.googleapis.com/token')) return sim.tokenBad? Response.json({error:'invalid_grant'},{status:400}) : Response.json({access_token:'AT',expires_in:3600});
  if(sim.driveDown && url.includes('googleapis.com/drive')) return new Response('',{status:500});
  if(url.includes('/upload/drive/v3/files')){ const id='f'+(++fileSeq); const buf=await new Response(init.body).arrayBuffer(); drive.set(id,{size:buf.byteLength,body:buf}); return Response.json({id}) }
  if(url.match(/drive\/v3\/files\?fields=id$/)){ const id='d'+(++fileSeq); drive.set(id,{folder:true,meta:JSON.parse(init.body)}); return Response.json({id}) }
  let m; if((m=url.match(/drive\/v3\/files\/([^?]+)\?alt=media/))){ const f=drive.get(m[1]); return f?new Response(f.body,{headers:{'Content-Type':'image/webp'}}):new Response('',{status:404}) }
  if((m=url.match(/drive\/v3\/files\/([^?]+)\?fields=id/)) && init.method==='PATCH'){ const f=drive.get(m[1]); if(f) f.trashed=true; return Response.json({id:m[1]}) }
  if(url.includes('turnstile')) return Response.json({success:true});
  if(url.startsWith('https://web.push.apple.com/')){ pushes.push({url,init}); return new Response('',{status: url.endsWith('/gone')?410:201}) }
  throw new Error('unexpected fetch '+url) }

const envAdmin = {DB, ...baseEnv};
const envPublic = {DB, GOOGLE_CLIENT_ID:'c',GOOGLE_CLIENT_SECRET:'s',GOOGLE_REFRESH_TOKEN:'r'};
const base='https://x.pages.dev';
async function call(env, method, path, {body, token, headers={}, form}={}){
  const h={...headers}; if(token) h['Cookie']=`hg_admin=${token}`; if(method!=='GET') h['X-Howgee']=h['X-Howgee']??'1';
  if(body!==undefined){h['Content-Type']='application/json'}
  const req=new Request(base+path,{method,headers:h,body: form ?? (body!==undefined?JSON.stringify(body):undefined)});
  const res=await handle(req, env, {waitUntil(p){pending.push(p)}}, {fetch:fakeFetch}); let data; const ct=res.headers.get('content-type')||'';
  data = ct.includes('json')? await res.json(): await res.arrayBuffer(); return {status:res.status, data, res} }
let fails=0; const ok=(c,msg)=>{ console.log((c?'PASS ':'FAIL ')+msg); if(!c) fails++ };

// --- admin auth ---
ok((await call(envAdmin,'GET','/api/admin/me')).status===401,'no token → 401');
ok((await call(envAdmin,'GET','/api/admin/me',{token:tampered})).status===401,'tampered → 401');
ok((await call(envAdmin,'GET','/api/admin/me',{token:expired})).status===401,'expired → 401');
ok((await call(envAdmin,'GET','/api/admin/me',{token:wrongEmail})).status===403,'wrong email → 403');
ok((await call(envAdmin,'GET','/api/admin/me',{token:otherSecret})).status===401,'signed with other secret → 401');
ok((await call(envAdmin,'GET','/api/admin/me',{token:good+'.x'})).status===401,'extra part → 401');
ok((await call({...envAdmin,ADMIN_EMAILS:''},'GET','/api/admin/me',{token:good})).status===503,'missing emails → 503 (fail closed)');
ok((await call({...envAdmin,ADMIN_SESSION_SECRET:'short'},'GET','/api/admin/me',{token:good})).status===503,'short secret → 503 (fail closed)');
ok((await call(envAdmin,'POST','/api/admin/listings',{token:good,body:{},headers:{Origin:'https://evil.example.com'}})).status===403,'POST from other origin → 403');
// --- 구글 로그인 흐름 ---
{ const st=await call(envAdmin,'GET','/api/admin/auth/login'); const loc=new URL(st.res.headers.get('location')); const ck=st.res.headers.get('set-cookie')||'';
  ok(st.status===302 && loc.origin==='https://accounts.google.com' && loc.searchParams.get('client_id')==='c' && loc.searchParams.get('scope')==='openid email','login → google');
  ok(loc.searchParams.get('redirect_uri')===base+'/api/admin/auth/callback' && loc.searchParams.get('code_challenge_method')==='S256','redirect_uri + PKCE');
  ok(/hg_oauth=[^;]+;.*HttpOnly.*Secure.*SameSite=Lax/.test(ck),'state cookie HttpOnly/Secure/Lax');
  const state=loc.searchParams.get('state'); const stateCookie=ck.match(/hg_oauth=([^;]+)/)[1];
  const cb=(q,cookie=stateCookie)=>call(envAdmin,'GET','/api/admin/auth/callback?'+q,{headers:{Cookie:`hg_oauth=${cookie}`}});
  let r=await cb(`code=abc&state=${state}`); const sc=r.res.headers.get('set-cookie')||'';
  ok(r.status===302 && r.res.headers.get('location')==='/' && /hg_admin=[^;]+;.*HttpOnly.*Secure.*SameSite=Strict/.test(sc),'callback ok → session cookie');
  ok(sim2.lastTokenBody.get('code_verifier')===stateCookie.split('.')[1] && sim2.lastTokenBody.get('redirect_uri')===base+'/api/admin/auth/callback','PKCE verifier sent');
  const sess=sc.match(/hg_admin=([^;]+)/)[1]; ok((await call(envAdmin,'GET','/api/admin/me',{token:sess})).data.email==='boss@example.com','session works');
  ok((await cb(`code=abc&state=WRONG`)).res.headers.get('location')==='/?login=expired','wrong state → expired');
  ok((await cb(`code=abc&state=${state}`,'')).res.headers.get('location')==='/?login=expired','no state cookie → expired');
  ok((await cb(`error=access_denied&state=${state}`)).res.headers.get('location')==='/?login=cancel','google cancel');
  sim2.id={...sim2.id,email:'x@y.com'}; ok((await cb(`code=abc&state=${state}`)).res.headers.get('location')==='/?login=notallowed','not admin email → notallowed');
  sim2.id={...sim2.id,email:'boss@example.com',email_verified:false}; ok((await cb(`code=abc&state=${state}`)).res.headers.get('location')==='/?login=notallowed','unverified email → notallowed');
  sim2.id={...sim2.id,email_verified:true,aud:'other'}; ok((await cb(`code=abc&state=${state}`)).res.headers.get('location')==='/?login=failed','wrong aud → failed');
  sim2.id={...sim2.id,aud:'c',iss:'https://evil.example.com'}; ok((await cb(`code=abc&state=${state}`)).res.headers.get('location')==='/?login=failed','wrong iss → failed');
  sim2.id={...sim2.id,iss:'https://accounts.google.com',exp:now-10}; ok((await cb(`code=abc&state=${state}`)).res.headers.get('location')==='/?login=failed','expired id token → failed');
  sim2.id={...sim2.id,exp:now+3600}; sim2.tokenFail=true; ok((await cb(`code=abc&state=${state}`)).res.headers.get('location')==='/?login=failed','token exchange error → failed'); sim2.tokenFail=false;
  ok((await call(envPublic,'GET','/api/admin/auth/login')).status===404,'customer site has no login');
  const lo=await call(envAdmin,'POST','/api/admin/auth/logout'); ok(lo.status===200 && /hg_admin=;.*Max-Age=0/.test(lo.res.headers.get('set-cookie')||''),'logout clears cookie');
  ok((await call(envAdmin,'POST','/api/admin/auth/logout',{headers:{'X-Howgee':''}})).status===403,'logout needs CSRF header');
}
ok((await call(envPublic,'GET','/api/admin/me',{token:good})).status===404,'customer site has no admin API');
const me=await call(envAdmin,'GET','/api/admin/me',{token:good}); ok(me.status===200 && me.data.email==='boss@example.com','good token → 200');
ok((await call(envAdmin,'POST','/api/admin/listings',{token:good,body:{},headers:{'X-Howgee':''}})).status===403,'POST without CSRF header → 403');

// --- create listing ---
ok((await call(envAdmin,'POST','/api/admin/listings',{token:good,body:{title:'x'}})).status===400,'missing required → 400');
const bad=await call(envAdmin,'POST','/api/admin/listings',{token:good,body:{title:'x',ptype:'궁전',deal:'월세'}}); ok(bad.status===400 && bad.data.error.includes('매물 종류'),'bad enum → 400 with Korean label: '+bad.data.error);
const c1=await call(envAdmin,'POST','/api/admin/listings',{token:good,body:{title:'강남 역삼동 빌라',sido:'서울',gu:'강남구',dong:'역삼동',ptype:'빌라',deal:'전세',price:25000,area:59.4,rooms:2,baths:1,unit:'101동 202호',owner_contact:'010-0000-0000',memo:'비밀메모',evil:'x'}});
ok(c1.status===200 && /^역삼동-[a-z0-9]{4}$/.test(c1.data.id),'create → id '+c1.data.id);
const id=c1.data.id;
const c2=await call(envAdmin,'POST','/api/admin/listings',{token:good,body:{title:'완료매물',ptype:'원룸',deal:'월세',price:1000,rent:70,status:'거래완료'}});

// --- public list hides private + 거래완료 ---
let pub=await call(envPublic,'GET','/api/listings');
const item=pub.data.items.find(i=>i.id===id);
ok(pub.data.items.length===1 && item,'public shows only visible');
ok(item && !('unit' in item) && !('owner_contact' in item) && !('memo' in item) && !('drive_folder_id' in item),'public hides private fields');
ok(!JSON.stringify(pub.data).includes('비밀메모'),'secret memo not in public JSON');

// --- photos ---
const fd=()=>{const f=new FormData(); f.append('full',new Blob([new Uint8Array(2000)],{type:'image/webp'}),'a.webp'); f.append('thumb',new Blob([new Uint8Array(500)],{type:'image/webp'}),'a_t.webp'); return f};
const p1=await call(envAdmin,'POST',`/api/admin/listings/${id}/photos`,{token:good,form:fd()}); ok(p1.status===200,'upload photo 1 '+JSON.stringify(p1.data));
const p2=await call(envAdmin,'POST',`/api/admin/listings/${id}/photos`,{token:good,form:fd()}); ok(p2.status===200,'upload photo 2');
const badf=new FormData(); badf.append('full',new Blob(['x'],{type:'text/html'}),'a.html'); badf.append('thumb',new Blob(['x'],{type:'image/webp'}),'t.webp');
ok((await call(envAdmin,'POST',`/api/admin/listings/${id}/photos`,{token:good,form:badf})).status===400,'reject non-image');
ok([...drive.values()].filter(f=>f.folder).length===2,'root + listing folder created once');
pub=await call(envPublic,'GET','/api/listings'); ok(pub.data.items[0].photos.length===2,'public lists photo ids');
const img=await call(envPublic,'GET',`/api/photo/${p1.data.id}?s=t`); ok(img.status===200 && img.data.byteLength>0 && img.res.headers.get('Cross-Origin-Resource-Policy')==='same-origin','public photo proxied ('+img.data.byteLength+'B)');
ok(/max-age=604800/.test(img.res.headers.get('Cache-Control')||'') && /immutable/.test(img.res.headers.get('Cache-Control')||''),'public photo cached 7 days in browser');
{ // Cloudflare 서버 캐시: 보관본은 1일, 캐시에서 꺼내 보낼 때도 브라우저엔 7일
  const store=new Map(); globalThis.caches={default:{async match(k){const r=store.get(k.url);return r?r.clone():undefined},async put(k,r){store.set(k.url,r)}}};
  const a=await call(envPublic,'GET',`/api/photo/${p1.data.id}?s=t`); await Promise.all(pending.splice(0));
  const edgeCC=[...store.values()][0]?.headers.get('Cache-Control');
  const b=await call(envPublic,'GET',`/api/photo/${p1.data.id}?s=t`);
  ok(a.res.headers.get('Cache-Control').includes('max-age=604800') && edgeCC==='public, max-age=86400','edge copy 1 day, browser 7 days (miss)');
  ok(b.status===200 && b.data.byteLength>0 && b.res.headers.get('Cache-Control').includes('max-age=604800'),'cache hit also sends 7 days to browser');
  delete globalThis.caches;
}
const imgf=await call(envPublic,'GET',`/api/photo/${p1.data.id}?s=f`); ok(imgf.data.byteLength>img.data.byteLength,'full larger than thumb (multipart body includes file)');
ok((await call(envPublic,'GET','/api/photo/nope')).status===404,'unknown photo 404');
// order
const ord=await call(envAdmin,'PUT',`/api/admin/listings/${id}/photos/order`,{token:good,body:{ids:[p2.data.id,p1.data.id]}}); ok(ord.status===200,'reorder');
pub=await call(envPublic,'GET','/api/listings'); ok(pub.data.items[0].photos[0]===p2.data.id,'order applied');
ok((await call(envAdmin,'PUT',`/api/admin/listings/${id}/photos/order`,{token:good,body:{ids:['zzz']}})).status===400,'reorder with foreign ids rejected');

// --- 조회수 ---
for (let i=0;i<3;i++) await call(envPublic,'POST',`/api/listings/${id}/view`);
ok(db.prepare('SELECT views FROM listings WHERE id=?').get(id).views===3,'views counted (3)');
pub=await call(envPublic,'GET','/api/listings');
ok(!('views' in pub.data.items[0]) && !JSON.stringify(pub.data).includes('"views"'),'view count NOT sent to customers');
ok(JSON.stringify(pub.data.popular)===JSON.stringify([id]),'popular order sent (ids only)');
const adm=await call(envAdmin,'GET','/api/admin/listings',{token:good}); ok(adm.data.items.find(i=>i.id===id).views===3,'admin sees view count');
ok((await call(envAdmin,'PUT',`/api/admin/listings/${id}`,{token:good,body:{views:999}})).status===400,'admin cannot set views by hand');
ok((await call(envPublic,'POST','/api/listings/bad-id/view')).status===404,'bad id view 404');
await call(envPublic,'POST',`/api/listings/${c2.data.id}/view`);
ok(db.prepare('SELECT views FROM listings WHERE id=?').get(c2.data.id).views===0,'hidden listing view not counted');

// --- status change hides from public, photo blocked ---
ok((await call(envAdmin,'PUT',`/api/admin/listings/${id}`,{token:good,body:{status:'거래완료'}})).status===200,'status change');
pub=await call(envPublic,'GET','/api/listings'); ok(pub.data.items.length===0,'거래완료 hidden');
ok((await call(envPublic,'GET',`/api/photo/${p1.data.id}`)).status===404,'photo of hidden listing blocked publicly');
ok((await call(envAdmin,'GET',`/api/admin/photo/${p1.data.id}`,{token:good})).status===200,'admin can still see photo');
await call(envAdmin,'PUT',`/api/admin/listings/${id}`,{token:good,body:{status:'거래가능',price:26000}});
const al=await call(envAdmin,'GET','/api/admin/listings',{token:good}); const a=al.data.items.find(i=>i.id===id);
ok(a.memo==='비밀메모' && a.price===26000 && al.data.items.length===2,'admin sees private + update applied');

// --- 가격 천원 단위 (만원 소수 1자리) ---
{
  const c2id=c2.data.id;
ok(/^매물-[a-z0-9]{4}$/.test(c2id),'no region → 매물-xxxx id '+c2id);
  const u=await call(envAdmin,'PUT',`/api/admin/listings/${c2id}`,{token:good,body:{rent:45.5,maint:'5.55',price:'1,000',rooms:2.6}});
  ok(u.status===200,'decimal price update accepted');
  const g=(await call(envAdmin,'GET','/api/admin/listings',{token:good})).data.items.find(i=>i.id===c2id);
  ok(g.rent===45.5 && g.maint===5.6 && g.price===1000 && g.rooms===3,`천원 단위 저장: rent ${g.rent}, maint ${g.maint}, price ${g.price}, rooms ${g.rooms}`);
  ok((await call(envAdmin,'PUT',`/api/admin/listings/${c2id}`,{token:good,body:{rent:-1}})).status===400,'negative rent → 400');
  ok((await call(envAdmin,'PUT',`/api/admin/listings/${c2id}`,{token:good,body:{rent:'45만'}})).status===400,'non-number rent → 400');
}

// --- 추가 거래유형 (월세+전세+매매 등 모든 조합) ---
{
  const mk=(b)=>call(envAdmin,'POST','/api/admin/listings',{token:good,body:{title:'복합',ptype:'아파트',deal:'월세',price:5000,rent:120,...b}});
  const x=await mk({extra_deals:[{deal:'전세',price:30000},{deal:'매매',price:'85,000.5'},{deal:'단기',rent:200}]});
  ok(x.status===200,'create with 3 extra deals');
  const row=(await call(envAdmin,'GET','/api/admin/listings',{token:good})).data.items.find(i=>i.id===x.data.id);
  const ex=JSON.parse(row.extra_deals);
  ok(ex.length===3 && ex[0].deal==='전세' && ex[0].price===30000 && ex[1].price===85000.5 && ex[2].deal==='단기' && ex[2].price===0 && ex[2].rent===200,'extra deals stored: '+row.extra_deals);
  const pubx=(await call(envPublic,'GET','/api/listings')).data.items.find(i=>i.id===x.data.id);
  ok(pubx && pubx.extra_deals===row.extra_deals,'extra deals visible on public list');
  ok((await mk({extra_deals:[{deal:'월세',rent:50}]})).status===400,'extra same as primary → 400');
  ok((await mk({extra_deals:[{deal:'전세',price:1},{deal:'전세',price:2}]})).status===400,'duplicate extra → 400');
  ok((await mk({extra_deals:[{deal:'전세'}]})).status===400,'extra without price → 400');
  ok((await mk({extra_deals:[{deal:'궁전',price:1}]})).status===400,'bad extra deal type → 400');
  ok((await mk({extra_deals:'not json'})).status===400,'bad extra json → 400');
  const e0=await mk({extra_deals:[]}); const r0=(await call(envAdmin,'GET','/api/admin/listings',{token:good})).data.items.find(i=>i.id===e0.data.id);
  ok(e0.status===200 && r0.extra_deals===null,'empty extra list → null');
  await call(envAdmin,'DELETE',`/api/admin/listings/${x.data.id}`,{token:good}); await call(envAdmin,'DELETE',`/api/admin/listings/${e0.data.id}`,{token:good});
}

// --- inquiries ---
const iq=(b,ip='1.1.1.1')=>call(envPublic,'POST','/api/inquiries',{body:b,headers:{'CF-Connecting-IP':ip}});
ok((await iq({phone:'010-1234-5678'})).status===400,'no consent → 400');
ok((await iq({phone:'12',consent:true,age14:true})).status===400,'bad phone → 400');
ok((await iq({phone:'010-1234-5678',consent:true})).status===400,'no age14 → 400');
const hp=await iq({phone:'010-1234-5678',consent:true,age14:true,website:'spam'}); ok(hp.status===200,'honeypot silently ok');
ok((await iq({phone:'010-1234-5678',consent:true,age14:true,name:'홍길동',message:'보고싶어요',listingId:id})).status===200,'inquiry 1');
await iq({phone:'010-1234-5678',consent:true,age14:true}); await iq({phone:'010-1234-5678',consent:true,age14:true});
ok((await iq({phone:'010-1234-5678',consent:true,age14:true})).status===429,'rate limited after 3 in 10min');
ok((await iq({phone:'010-1234-5678',consent:true,age14:true},'2.2.2.2')).status===200,'other IP fine');
const ts=await call({...envPublic,TURNSTILE_SECRET:'sec'},'POST','/api/inquiries',{body:{phone:'01012345678',consent:true,age14:true,turnstileToken:'t'},headers:{'CF-Connecting-IP':'3.3.3.3'}}); ok(ts.status===200,'turnstile path');
const inq=await call(envAdmin,'GET','/api/admin/inquiries',{token:good}); ok(inq.data.items.length===5 && inq.data.items.some(i=>i.listing_title==='강남 역삼동 빌라'),'admin inquiry list ('+inq.data.items.length+')');
ok(!('ip_hash' in inq.data.items[0]),'ip hash not exposed');
const iid=inq.data.items[0].id;
ok((await call(envAdmin,'PUT',`/api/admin/inquiries/${iid}`,{token:good,body:{status:'연락함',admin_memo:'내일 통화'}})).status===200,'inquiry update');
ok((await call(envAdmin,'PUT',`/api/admin/inquiries/${iid}`,{token:good,body:{status:'??'}})).status===400,'bad inquiry status');
ok((await call(envPublic,'GET','/api/admin/inquiries')).status===404,'inquiries not reachable on customer site');
const fv=await iq({phone:'010-2222-3333',consent:true,age14:true,message:'같이 보고싶어요',listingIds:[id,id,'bad id','20991231-zzzz',"x' OR 1=1"]},'4.4.4.4'); ok(fv.status===200,'fav multi inquiry');
const fr=db.prepare("SELECT listing_id, listing_title, message FROM inquiries WHERE phone='01022223333'").get();
ok(fr && fr.listing_id===id && fr.listing_title.startsWith('[관심매물 1개]') && fr.message.includes('· '+id) && fr.message.endsWith('같이 보고싶어요') && !fr.message.includes('zzzz'),'fav inquiry: server titles, bad ids dropped');

// --- 새 문의 알림 (웹 푸시) ---
const sm0=await call(envAdmin,'GET','/api/admin/inquiries/summary',{token:good}); ok(sm0.status===200 && sm0.data.newCount>=1 && sm0.data.latest,'inquiry summary ('+sm0.data.newCount+')');
ok((await call(envPublic,'GET','/api/admin/push')).status===404,'push settings not on customer site');
const pk=await call(envAdmin,'GET','/api/admin/push',{token:good}); ok(pk.status===200 && /^[A-Za-z0-9_-]{87}$/.test(pk.data.key) && pk.data.devices===0,'vapid key auto-created');
const pk2=await call(envAdmin,'GET','/api/admin/push',{token:good}); ok(pk2.data.key===pk.data.key,'vapid key stable');
const ua=await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveBits']);
const uaPub=new Uint8Array(await crypto.subtle.exportKey('raw',ua.publicKey)); const uaAuth=crypto.getRandomValues(new Uint8Array(16));
const sub={endpoint:'https://web.push.apple.com/3/device/abc',keys:{p256dh:b64u(uaPub),auth:b64u(uaAuth)},label:'iPhone'};
ok((await call(envAdmin,'POST','/api/admin/push/subscribe',{token:good,body:{...sub,endpoint:'https://evil.example.com/x'}})).status===400,'push endpoint allowlist (no SSRF)');
ok((await call(envAdmin,'POST','/api/admin/push/subscribe',{token:good,body:{...sub,keys:{p256dh:'x',auth:'y'}}})).status===400,'push bad keys → 400');
const sb=await call(envAdmin,'POST','/api/admin/push/subscribe',{token:good,body:sub}); ok(sb.status===200 && sb.data.devices===1,'push subscribe');
async function openPush(p){ // 기기 쪽에서 알림 풀기 (RFC 8291)
  const b=new Uint8Array(await new Response(p.init.body).arrayBuffer()); const salt=b.slice(0,16), idlen=b[20], asPub=b.slice(21,21+idlen), ct=b.slice(21+idlen);
  const asKey=await crypto.subtle.importKey('raw',asPub,{name:'ECDH',namedCurve:'P-256'},false,[]);
  const shared=new Uint8Array(await crypto.subtle.deriveBits({name:'ECDH',public:asKey},ua.privateKey,256));
  const te=new TextEncoder(); const hk=async(sa,ikm,info,len)=>new Uint8Array(await crypto.subtle.deriveBits({name:'HKDF',hash:'SHA-256',salt:sa,info},await crypto.subtle.importKey('raw',ikm,'HKDF',false,['deriveBits']),len*8));
  const ikm=await hk(uaAuth,shared,new Uint8Array([...te.encode('WebPush: info\0'),...uaPub,...asPub]),32);
  const cek=await hk(salt,ikm,te.encode('Content-Encoding: aes128gcm\0'),16), nonce=await hk(salt,ikm,te.encode('Content-Encoding: nonce\0'),12);
  const pt=new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:nonce},await crypto.subtle.importKey('raw',cek,'AES-GCM',false,['decrypt']),ct));
  return JSON.parse(new TextDecoder().decode(pt.slice(0,pt.lastIndexOf(2)))) }
async function vapidOk(p){ const m=p.init.headers.Authorization.match(/^vapid t=([^.]+)\.([^.]+)\.([^,]+), k=(.+)$/); if(!m||m[4]!==pk.data.key) return false;
  const claims=JSON.parse(Buffer.from(m[2],'base64url')); if(claims.aud!=='https://web.push.apple.com'||!claims.sub.startsWith('mailto:')||claims.exp>now+3700) return false;
  const key=await crypto.subtle.importKey('raw',Buffer.from(m[4],'base64url'),{name:'ECDSA',namedCurve:'P-256'},false,['verify']);
  return crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},key,Buffer.from(m[3],'base64url'),new TextEncoder().encode(m[1]+'.'+m[2])) }
const tp=await call(envAdmin,'POST','/api/admin/push/test',{token:good}); ok(tp.status===200 && tp.data.sent===1 && pushes.length===1,'push test sent');
const msg1=await openPush(pushes[0]); ok(msg1.title.includes('테스트') && pushes[0].init.headers['Content-Encoding']==='aes128gcm','push payload decrypts on device');
ok(await vapidOk(pushes[0]),'push VAPID signature valid');
pushes.length=0; pending.length=0;
ok((await iq({phone:'010-5555-6666',consent:true,age14:true,name:'김푸시',region:'전포동'},'5.5.5.5')).status===200,'inquiry with push');
await Promise.all(pending); const msg2=pushes[0] && await openPush(pushes[0]);
ok(msg2 && msg2.title==='하우지 새 문의' && msg2.body.includes('김푸시') && !msg2.body.includes('5555') && msg2.url==='/#inq','inquiry push: name shown, phone hidden');
await call(envAdmin,'POST','/api/admin/push/subscribe',{token:good,body:{...sub,endpoint:'https://web.push.apple.com/3/device/gone'}});
pushes.length=0; const tp2=await call(envAdmin,'POST','/api/admin/push/test',{token:good}); ok(tp2.data.total===2 && tp2.data.sent===1 && tp2.data.failed===1,'gone device counted failed');
ok((await call(envAdmin,'GET','/api/admin/push',{token:good})).data.devices===1,'gone device auto-removed');
const us=await call(envAdmin,'POST','/api/admin/push/unsubscribe',{token:good,body:{endpoint:sub.endpoint}}); ok(us.data.devices===0,'push unsubscribe');

// --- 카톡·인스타 보내기 기록 (문의 목록에 경로 표시) ---
const sh1=await call(envPublic,'POST','/api/inquiries/share',{body:{channel:'카톡',listingIds:[id,'없는-zzzz'],conds:{text:'입주: 즉시\n예산: 보증금 1,000 / 월 30만 이하',budget:'보증금 1,000 / 월 30만 이하',moveIn:'즉시'}}});
ok(sh1.status===200,'share log kakao → 200');
let inqs=(await call(envAdmin,'GET','/api/admin/inquiries',{token:good})).data.items;
const kk=inqs.find(x=>x.channel==='카톡');
ok(kk && kk.listing_id===id && kk.phone==='' && kk.name===null && kk.status==='신규' && kk.message.includes('카톡') && kk.message.includes('강남 역삼동 빌라') && !kk.message.includes('없는-zzzz') && kk.budget.includes('1,000'),'kakao record: listing title from DB, no phone/name');
await call(envPublic,'POST','/api/inquiries/share',{body:{channel:'카톡',listingIds:[id,'없는-zzzz'],conds:{text:'입주: 즉시\n예산: 보증금 1,000 / 월 30만 이하'}}});
ok((await call(envAdmin,'GET','/api/admin/inquiries',{token:good})).data.items.filter(x=>x.channel==='카톡').length===1,'same share within 30 min → recorded once');
await call(envPublic,'POST','/api/inquiries/share',{body:{channel:'인스타',conds:{text:'구조: 투룸'}}});
inqs=(await call(envAdmin,'GET','/api/admin/inquiries',{token:good})).data.items;
ok(inqs.some(x=>x.channel==='인스타' && !x.listing_id && x.message.includes('투룸')),'insta record with conditions only');
ok(inqs.filter(x=>x.channel==='사이트').length>=1 && inqs.every(x=>['사이트','카톡','인스타'].includes(x.channel)),'site inquiries shown as 사이트');
ok((await call(envPublic,'POST','/api/inquiries/share',{body:{channel:'문자',listingIds:[id]}})).status===400,'unknown channel → 400');
const beforeN=db.prepare("SELECT COUNT(*) c FROM inquiries").get().c;
await call(envPublic,'POST','/api/inquiries/share',{body:{channel:'카톡'}});
ok(db.prepare("SELECT COUNT(*) c FROM inquiries").get().c===beforeN,'empty share not recorded');
for(let i=0;i<8;i++) await call(envPublic,'POST','/api/inquiries/share',{body:{channel:'인스타',conds:{text:'스팸'+i}}});
ok(db.prepare("SELECT COUNT(*) c FROM inquiries WHERE channel='인스타'").get().c<=5,'share spam limited (5 per 10 min)');
const site2=await call(envPublic,'POST','/api/inquiries',{body:{phone:'010-2222-3333',consent:true,age14:true,message:'공유 많이 눌러도 사이트 문의는 됨'}});
ok(site2.status===200,'share clicks do not block site inquiry limit');
// --- 도배 대비: 알림 제외, 스위치, 1시간 상한, 자동 정리, 한 번에 지우기 ---
{ const sum=(await call(envAdmin,'GET','/api/admin/inquiries/summary',{token:good})).data;
  const siteNew=db.prepare("SELECT COUNT(*) c FROM inquiries WHERE status='신규' AND COALESCE(channel,'사이트')='사이트'").get().c;
  ok(sum.newCount===siteNew && db.prepare("SELECT COUNT(*) c FROM inquiries WHERE channel IN ('카톡','인스타') AND status='신규'").get().c>0,'alert count excludes kakao/insta records'); }
ok((await call(envPublic,'GET','/api/admin/guard')).status===404 && (await call(envAdmin,'GET','/api/admin/guard')).status===401,'guard settings admin only');
let g=(await call(envAdmin,'GET','/api/admin/guard',{token:good})).data; ok(g.shareLog===true && g.siteInquiry===true && g.shareCount>0,'switches default on');
await call(envAdmin,'PUT','/api/admin/guard',{token:good,body:{shareLog:false,siteInquiry:false}});
{ const n0=db.prepare('SELECT COUNT(*) c FROM inquiries').get().c;
  await call(envPublic,'POST','/api/inquiries/share',{headers:{'CF-Connecting-IP':'9.9.9.1'},body:{channel:'카톡',conds:{text:'꺼짐 테스트'}}});
  ok(db.prepare('SELECT COUNT(*) c FROM inquiries').get().c===n0,'share log off → not recorded');
  const off=await call(envPublic,'POST','/api/inquiries',{headers:{'CF-Connecting-IP':'9.9.9.2'},body:{phone:'010-1111-2222',consent:true,age14:true}});
  ok(off.status===503 && off.data.error.includes('전화'),'site inquiry off → friendly 503');
  ok((await call(envPublic,'GET','/api/listings')).data.inquiryOpen===false,'listings tell customer form is closed'); }
await call(envAdmin,'PUT','/api/admin/guard',{token:good,body:{shareLog:true,siteInquiry:true}});
ok((await call(envPublic,'GET','/api/listings')).data.inquiryOpen===true,'switch back on');
{ const ins=db.prepare("INSERT INTO inquiries (id,phone,status,created_at,channel,ip_hash,message) VALUES (?,?,?,?,?,?,?)");
  const nowIso=new Date().toISOString();
  for(let i=0;i<30;i++) ins.run('h'+i,'','신규',nowIso,'카톡','other'+i,'x'+i);
  const n0=db.prepare("SELECT COUNT(*) c FROM inquiries WHERE channel IN ('카톡','인스타')").get().c;
  await call(envPublic,'POST','/api/inquiries/share',{headers:{'CF-Connecting-IP':'9.9.9.3'},body:{channel:'인스타',conds:{text:'상한 테스트'}}});
  ok(db.prepare("SELECT COUNT(*) c FROM inquiries WHERE channel IN ('카톡','인스타')").get().c===n0,'site-wide hourly cap for share logs');
  for(let i=0;i<30;i++) ins.run('s'+i,'01000000000','신규',nowIso,'사이트','site'+i,'y');
  const cap=await call(envPublic,'POST','/api/inquiries',{headers:{'CF-Connecting-IP':'9.9.9.4'},body:{phone:'010-3333-4444',consent:true,age14:true}});
  ok(cap.status===429,'site-wide hourly cap for site inquiries');
  db.exec("DELETE FROM inquiries WHERE id LIKE 's%' AND ip_hash LIKE 'site%'");
  const old=(d)=>new Date(Date.now()-d*86400000).toISOString();
  ins.run('old1','','신규',old(91),'카톡','o','old share'); ins.run('old2','01000000000','완료',old(400),'사이트','o','old site'); ins.run('keep1','01000000000','완료',old(300),'사이트','o','keep');
  await call(envAdmin,'GET','/api/admin/inquiries',{token:good});
  const ids=db.prepare("SELECT id FROM inquiries WHERE id IN ('old1','old2','keep1')").all().map(r=>r.id);
  ok(!ids.includes('old1') && !ids.includes('old2') && ids.includes('keep1'),'auto cleanup: share >90d, all >13 months');
  ok((await call(envAdmin,'DELETE','/api/admin/inquiries/share-logs',{token:good})).status===200 && db.prepare("SELECT COUNT(*) c FROM inquiries WHERE channel IN ('카톡','인스타')").get().c===0 && db.prepare("SELECT COUNT(*) c FROM inquiries WHERE COALESCE(channel,'사이트')='사이트'").get().c>0,'delete all share logs keeps site inquiries'); }
// --- 운영자가 카톡·인스타 기록에 경로·이름·연락처 적기 ---
{ const ins=db.prepare("INSERT INTO inquiries (id,phone,status,created_at,channel,ip_hash,message) VALUES (?,?,?,?,?,?,?)");
  const old=(d)=>new Date(Date.now()-d*86400000).toISOString();
  ins.run('kE','', '신규', old(100), '카톡','e','old kakao edited'); ins.run('kU','', '신규', old(100), '카톡','e','old kakao untouched'); ins.run('kN','', '신규', old(1), '인스타','e','new insta');
  const up=await call(envAdmin,'PUT','/api/admin/inquiries/kE',{token:good,body:{name:'김손님(카톡: 집구해요)',phone:'010-9999-8888'}});
  ok(up.status===200,'edit name/contact on kakao record');
  ok((await call(envAdmin,'PUT','/api/admin/inquiries/kN',{token:good,body:{channel:'전화'}})).status===200 && db.prepare("SELECT channel FROM inquiries WHERE id='kN'").get().channel==='전화','change channel to 전화');
  ok((await call(envAdmin,'PUT','/api/admin/inquiries/kN',{token:good,body:{channel:'해킹'}})).status===400,'bad channel → 400');
  ok((await call(envPublic,'PUT','/api/admin/inquiries/kE',{body:{name:'x'}})).status===404,'customer site cannot edit');
  ok((await call(envAdmin,'PUT','/api/admin/inquiries/kE',{token:good,body:{name:'<script>'.repeat(20)}})).status===200 && db.prepare("SELECT name FROM inquiries WHERE id='kE'").get().name.length<=30,'name length limited');
  await call(envAdmin,'PUT','/api/admin/inquiries/kE',{token:good,body:{name:'김손님'}});
  await call(envAdmin,'GET','/api/admin/inquiries',{token:good});
  const left=db.prepare("SELECT id FROM inquiries WHERE id IN ('kE','kU')").all().map(r=>r.id);
  ok(left.includes('kE') && !left.includes('kU'),'auto cleanup keeps kakao records the operator filled in');
  ins.run('kU2','', '신규', old(1), '인스타','e','untouched');
  await call(envAdmin,'DELETE','/api/admin/inquiries/share-logs',{token:good});
  ok(db.prepare("SELECT COUNT(*) c FROM inquiries WHERE id='kE'").get().c===1 && db.prepare("SELECT COUNT(*) c FROM inquiries WHERE id='kU2'").get().c===0,'clear button keeps filled-in records, removes untouched'); }
// 예전 데이터베이스(경로 칸 없음) → 서버가 자동으로 칸 추가
{ const db2=new DatabaseSync(':memory:'); db2.exec(readFileSync(new URL('../db/schema.sql', import.meta.url),'utf8').replace(', channel TEXT);', ');'));
  ok(!db2.prepare('PRAGMA table_info(inquiries)').all().some(c=>c.name==='channel'),'old DB has no channel column (setup)');
  class S2 extends Stmt{ first(){return Promise.resolve(db2.prepare(this.sql).get(...this.args)??null)} all(){return Promise.resolve({results:db2.prepare(this.sql).all(...this.args)})} run(){db2.prepare(this.sql).run(...this.args);return Promise.resolve({success:true})} _exec(){const s=db2.prepare(this.sql);return /^\s*select/i.test(this.sql)?{results:s.all(...this.args)}:(s.run(...this.args),{results:[]})} }
  const DB2={prepare:(s)=>new S2(s),batch:async(arr)=>arr.map(s=>s._exec())};
  const r=await call({...envPublic,DB:DB2},'POST','/api/inquiries/share',{body:{channel:'카톡',conds:{text:'입주: 즉시'}}});
  ok(r.status===200 && db2.prepare('PRAGMA table_info(inquiries)').all().some(c=>c.name==='channel') && db2.prepare("SELECT channel FROM inquiries").get().channel==='카톡','old DB: channel column auto-added'); }

// --- 상태 점검 · 지역 띄어쓰기 · 문의 때 자동 정리 · 드라이브 장애 시 삭제 ---
{ const h=await call(envAdmin,'GET','/api/admin/health',{token:good});
  ok(h.status===200 && h.data.checks.find(c=>c.name==='데이터베이스(D1)').ok && h.data.checks.find(c=>c.name==='구글 드라이브 연결').ok && h.data.checks.find(c=>c.name==='데이터베이스 칸').ok,'health: all core checks ok');
  ok((await call(envPublic,'GET','/api/admin/health')).status===404,'customer site has no health API');
  sim.tokenBad=true; const h2=await call(envAdmin,'GET','/api/admin/health',{token:good}); sim.tokenBad=false;
  const g=h2.data.checks.find(c=>c.name==='구글 드라이브 연결'); ok(h2.status===200 && !g.ok && g.detail.includes('invalid_grant'),'health: broken Google key shown: '+g.detail);
  const r=await call(envAdmin,'POST','/api/admin/listings',{token:good,body:{title:'띄어쓰기',sido:' 부산 광역시',gu:'해운대 구',dong:'우 1동',ptype:'원룸',deal:'월세',price:500,rent:40}});
  const row=db.prepare('SELECT sido,gu,dong FROM listings WHERE title=?').get('띄어쓰기'); ok(row.sido==='부산광역시'&&row.gu==='해운대구'&&row.dong==='우1동','region spaces removed');
  const ph=new FormData(); ph.append('full',new Blob([new Uint8Array(50)],{type:'image/webp'}),'a.webp'); ph.append('thumb',new Blob([new Uint8Array(20)],{type:'image/webp'}),'t.webp');
  const pr=await call(envAdmin,'POST',`/api/admin/listings/${encodeURIComponent(r.data.id)}/photos`,{token:good,form:ph}); ok(pr.status===200,'photo for drive-down test');
  sim.driveDown=true;
  const dp=await call(envAdmin,'DELETE',`/api/admin/photos/${pr.data.id}`,{token:good});
  ok(dp.status===200 && dp.data.driveWarning && db.prepare('SELECT COUNT(*) c FROM photos WHERE id=?').get(pr.data.id).c===0,'drive down: photo still deleted + warning');
  const dl=await call(envAdmin,'DELETE',`/api/admin/listings/${encodeURIComponent(r.data.id)}`,{token:good});
  ok(dl.status===200 && dl.data.driveWarning && db.prepare('SELECT COUNT(*) c FROM listings WHERE id=?').get(r.data.id).c===0,'drive down: listing still deleted + warning');
  sim.driveDown=false;
  db.prepare("INSERT INTO inquiries (id,phone,status,created_at,channel,ip_hash) VALUES ('veryold','01000000000','완료',?,'사이트','z')").run(new Date(Date.now()-400*86400000).toISOString());
  const before=pending.length;
  const iq=await call(envPublic,'POST','/api/inquiries',{body:{phone:'010-2222-3333',consent:true,age14:true},headers:{'CF-Connecting-IP':'9.9.9.9'}});
  await Promise.all(pending.slice(before));
  ok(iq.status===200 && db.prepare("SELECT COUNT(*) c FROM inquiries WHERE id='veryold'").get().c===0,'new inquiry also runs retention cleanup'); }

// --- 손님·운영자 화면 목록이 서버와 같은지 (한 곳만 고쳐서 어긋나는 실수 방지) ---
{ const F=await import('../lib/fields.js');
  const src={app:readFileSync(new URL('../public/js/app.js',import.meta.url),'utf8'), admin:readFileSync(new URL('../admin/js/admin.js',import.meta.url),'utf8')};
  const arr=(code,name)=>{ const m=code.match(new RegExp(`const ${name} = (\\[[^\\]]*\\])`)); return m?JSON.stringify(eval(m[1])):null };
  for(const [file,code] of Object.entries(src)){
    ok(arr(code,'TYPES')===JSON.stringify(F.TYPES),`${file}: 매물 종류 목록이 lib/fields.js 와 같음`);
    ok(arr(code,'DEALS')===JSON.stringify(F.DEALS),`${file}: 거래 유형 목록이 lib/fields.js 와 같음`); }
  ok(arr(src.admin,'STATUSES')===JSON.stringify(F.STATUSES),'admin: 상태 목록이 lib/fields.js 와 같음');
  ok(arr(src.admin,'INQ')===JSON.stringify(F.INQUIRY_STATUSES),'admin: 문의 상태 목록이 lib/fields.js 와 같음');
  const wonOf=(code)=>{ const m=code.match(/function won\(n\) \{[\s\S]*?\n  \}/); return m&&m[0].replace(/\s+/g,'') };
  ok(wonOf(src.app) && wonOf(src.app)===wonOf(src.admin),'가격 표시 규칙(won)이 손님·운영자 화면에서 같음'); }

// --- delete photo & listing ---
ok((await call(envAdmin,'DELETE',`/api/admin/photos/${p1.data.id}`,{token:good})).status===200,'delete photo');
const del=await call(envAdmin,'DELETE',`/api/admin/listings/${id}`,{token:good}); ok(del.status===200,'delete listing');
const folder=[...drive.entries()].find(([k,v])=>v.folder && v.meta.name===id); ok(folder && folder[1].trashed,'listing folder trashed (recoverable)');
ok(db.prepare('SELECT COUNT(*) c FROM photos').get().c===0,'photo rows removed');
ok((await call(envAdmin,'PUT',`/api/admin/listings/${id}`,{token:good,body:{status:'거래가능'}})).status===404,'deleted listing 404');
ok((await call({DB:undefined},'GET','/api/listings')).status===503,'missing DB → clear 503');
db.exec('ALTER TABLE listings DROP COLUMN views');
const old=await call(envPublic,'GET','/api/listings'); ok(old.status===503 && old.data.error.includes('업데이트'),'old DB without views → friendly 503');

ok((await call(envPublic,'GET','/api/../etc')).status===404,'unknown path 404');
// --- 매물번호 형식 ---
ok(LISTING_ID_RE.test('역삼1동-k3f9') && LISTING_ID_RE.test('20261122-k3f9') && !LISTING_ID_RE.test('역삼동-K3F9') && !LISTING_ID_RE.test('a/b-k3f9') && !LISTING_ID_RE.test("x' OR 1=1"),'listing id format (new + old)');
console.log(fails? `\n${fails} FAILED`:'\nALL PASSED'); process.exit(fails?1:0);
